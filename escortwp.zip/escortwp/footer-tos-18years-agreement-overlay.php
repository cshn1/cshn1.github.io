<div class="tosdisclaimer rad3" id="tosdisclaimer" style="display:none">
	<h4>YOU MUST AGREE TO THE FOLLOWING BEFORE ENTERING!</h4><br />
	<p><b>WARNING</b> - This area of the website may contain nudity and sexuality, and is intended for a mature person. It must not to be accessed by anyone under the age of 18 (or the age of consent in the jurisdiction from which it is being accessed).</p>
	<p>I am over age 18 years old, and I have the legal right to possess adult material in my community.</p>
	<p>I will not permit any person(s) under 18 years of age to have access to any of the materials contained in this site.</p>
	<p>I am familiar with the rules governing the viewing or possession of sexually oriented materials as defined by my local jurisdiction.</p>
	<p>I agree that responsibility for the editorial content, and/or the content of advertisers' pages do not necessarily reflect the opinions of the publisher of this website.</p>
	<p>I am voluntarily choosing to access this site, because I want to view, read and/or hear the various materials which are available. I do not find images of nude adults, adults engaged in sexual acts, or other sexual material to be offensive or objectionable.</p>
	<p>I will exit from this site immediately if I am in any way offended by the sexual nature of any material.</p>
	<p>I understand and agree to abide by the standards and laws of my community. By logging on and viewing any part of this website, I agree that I shall not hold the owners of the website or its employees responsible for any materials located on the site.</p>
	<p>This entire website, including it's code, images, logos, and names are protected by copyright, and any infringement of said copyright will be prosecuted to the fullest extent of the law. The creators of this website along with the services provided are released of all liabilities.</p>


<?php
/*
//if you have a lot of text to put here then place it in the div below.
//it will create a scrollable box with a fixed height
//remove the php tags here after that
?>
	<div class="tosdisclaimerscroll rad3">
	</div>
<?php */ ?>

	<div class="clear10"></div>
    <div class="tosdisclaimerbuttons">
		<div class="rad3 bluebutton entertosdisclaimer l">ENTER</div>
		<div class="rad3 redbutton closetosdisclaimer r">EXIT</div>
	</div>
	<div class="clear10"></div>
</div> <!-- TOS OVERLAY -->