<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );
if (!is_user_logged_in()) { die(); }

$escortid = (int)$_GET['id'];
if (!$escortid || $escortid < 1) { die(); }

global $current_user;
get_currentuserinfo();
$userid = $current_user->ID;

$escort = get_post($escortid);
$escort_author = $escort->post_author;
$status = $escort->post_status;

if ($escort_author == $current_user->ID || current_user_can('level_10')) {
	if ($status == "publish") {
		$status = "private";
		$ok = _d('Set to',781)." <strong>"._d('INACTIVE',782)."</strong>";
	} else {
		$status = "publish";
		$ok = _d('Set to',781)." <strong>"._d('ACTIVE',783)."</strong>";
	}

	$post_escort = array( 'ID' => $escortid, 'post_status' => $status );
	wp_update_post( $post_escort );
	echo $ok;
}
?>