<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );

if (strlen($_GET['user']) > 3 && strlen($_GET['user']) <= 30) {
	if (username_exists($_GET['user'])) { //sanitizing is done by WordPress
		echo '<span class="checkusererr">'._d('This username already exists.',772).'<br />'._d('Please choose another one',773).'</span>';
	} else {
		echo '<span class="checkuserok">'._d('This username is available',774).'</span>';
	}
}
?>