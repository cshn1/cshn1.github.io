<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );
global $current_user;
get_currentuserinfo();

if (is_user_logged_in()) {
	$emailhash = get_user_meta( $current_user->ID, "emailhash", true );
	if($emailhash) {
		$last_email_validation_sent = get_user_meta( $current_user->ID, "last_email_validation_sent", true );
		if (time() >= $last_email_validation_sent) {
			$body = _d('Hello',17).' '.$current_user->display_name.'<br /><br />
'._d('Before you can use the site you will need to validate your email address.',795).'
'._d('If you don\'t validate your email in the next 3 days your account will be deleted.',960).'<br /><br />
'._d('Please validate your email address by clicking the link bellow',1025).':
<a href="'.get_bloginfo('url').'/?ekey='.$emailhash.'">'.get_bloginfo('url').'/?ekey='.$emailhash.'</a>';
			dolce_email("", "", $current_user->user_email, _d('Email validation link',1026)." ".get_option("email_sitename"), $body);
			$one_min_from_now = time() + 30;
			update_user_meta( $current_user->ID, "last_email_validation_sent", $one_min_from_now );
			echo '<div class="ok rad5">'._d("We sent another validation link to your email address",1053)." ".$current_user->user_email."</div>";
		} else {
			echo '<div class="err rad5">'._d("You can only send one email every 30 seconds",1052)."</div>";
		} // if time of last email sent
	} else {
		echo '<div class="err rad5">'._d("Your email has already been validated",1050)."</div>";
	} // if email hash
} else {
	echo '<div class="err rad5">'._d("You need to be logged in to resend an activation link",1051)."</div>";
} // if user logged in
?>