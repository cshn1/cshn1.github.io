<?php
ini_set( 'display_errors', 0 );
require( '../../../../wp-load.php' );
if (!is_user_logged_in() || !$_GET['id']) { die(); }

$current_user = wp_get_current_user();
$postid = (int)$_GET['id'];
$userid = $current_user->ID;
$post = get_post($postid);

if($post->post_author == $userid || current_user_can('level_10')) {
	wp_delete_attachment($postid, true);
	_de('Your image has been deleted',174);
}
?>