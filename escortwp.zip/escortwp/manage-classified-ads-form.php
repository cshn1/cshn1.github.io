<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }
?>
<?php if ( $err && $_POST['action'] == 'addclassifiedad') { echo "<div class=\"err rad3\">$err</div>"; } ?>
<form action="<?php echo get_permalink(get_the_ID()); ?>" method="post" class="form-styling">
    <small class="mandatory l"><?php _de('Fields marked with <i>*</i> are mandatory',323); ?></small>
    <div class="clear20"></div>

    <input type="hidden" name="action" value="addclassifiedad" />
    <div class="form-label">
        <label for="classifiedadtype"><?php _de('Classified ad type',324); ?><i>*</i></label>
    </div>
    <div class="form-input">
        <?php _de('I am',325); ?> &nbsp;
        <select name="classifiedadtype" id="classifiedadtype">
    	   <option value="offering"<?php if ($classifiedadtype == "offering") { echo ' selected="selected"'; }?>><?php _de('offering',326); ?></option>
            <option value="looking"<?php if ($classifiedadtype == "looking") { echo ' selected="selected"'; }?>><?php _de('looking',327); ?></option>
        </select>
    </div> <!-- classifiedadtype --> <div class="formseparator"></div>

    <div class="form-label">
	   <label for="title"><?php _de('Title',328); ?><i>*</i></label>
    </div>
    <div class="form-input">
        <input type="text" name="adtitle" id="title" class="input longinput" value="<?php echo $title; ?>" />
    </div> <!-- title --> <div class="formseparator"></div>

    <div class="form-label">
        <label for="description"><?php _de('Description',329); ?><i>*</i></label>
    </div>
    <div class="form-input">
        <textarea name="description" id="description" class="textarea longtextarea" rows="7"><?php echo $description; ?></textarea>
        <small><?php _de('html code will be removed',83); ?></small>
	</div> <!-- description --> <div class="formseparator"></div>

    <div class="clear20"></div>
    <div class="mandatory"><?php _de('At least one of the fields below should be filled in',330); ?></div>
    <div class="clear10"></div>

    <div class="form-label">
		<label for="classifiedademail"><?php _de('Email',331); ?></label>
    </div>
    <div class="form-input">
        <input type="email" name="classifiedademail" id="classifiedademail" class="input longinput" value="<?php echo $classifiedademail; ?>" />
    </div> <!-- email --> <div class="formseparator"></div>

    <div class="form-label">
		<label for="classifiedadphone"><?php _de('Phone',332); ?></label>
    </div>
    <div class="form-input">
        <input type="text" name="classifiedadphone" id="classifiedadphone" class="input longinput" value="<?php echo $classifiedadphone; ?>" />
    </div> <!-- phone --> <div class="formseparator"></div>

    <div class="center"><input type="submit" name="submit" value="<?php if ($single_page) { _de('Update Classified Ad',333); } else { _de('Post this ad',334); }?>" class="bluebutton rad3" /></div> <!--center-->
</form>