<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }

global $current_user;
get_currentuserinfo();

if (!$member_edit_page) {
    $user = preg_replace("/([^a-zA-Z0-9])/", "", $_POST['user']);
	if ($user) {
		if (strlen($user) < 4 || strlen($user) > 30) { $err .= _d('Your username must be between 4 and 30 characters',498)."<br />"; } else {
			if (username_exists($user)) { $err .= _d('This username already exists. Please write another one',499)."<br />"; }
		}
	} else {
		$err .= _d('The username field is empty',500)."<br />";
	}

	$pass = $_POST['pass'];
	if ($pass) {
		if (strlen($pass) < 6 || strlen($pass) > 50) {
			$err .= _d('Your password must be between 6 and 50 characters',464)."<br />";
		} else {
			if ( false !== strpos( stripslashes($pass), "\\" ) ) {
				$err .= _d('Passwords may not contain the character "\"',785)."<br />";
			}
		}
	} else {
		$err .= _d('The password field is empty',466)."<br />";
	}
}


$membername = wp_strip_all_tags($_POST['membername'], true);
if (!$membername) { $err .= _d('Please write your name',562)."<br />"; }

$memberemail = $_POST['memberemail'];
if (!$memberemail) { $err .= _d('Please write your email address',501)."<br />"; } else {
	if ( !is_email($memberemail) ) { $err .= _d('Your email address seems to be wrong',561)."<br />"; }
	if ( email_exists($memberemail) && $memberemail != $current_user->user_email ) {
		$err .= _d('The email address has been used by someone else already',502)."<br />";
		if ($agency_post_id) {
			$agencyemail = $current_user->user_email;
		}
	}
}


//spam/emails field must be empty to continue
$emails = $_POST['emails'];
if ($emails != "") { $err = ".<br />"; }

if(get_option('recaptcha_sitekey') && get_option('recaptcha_secretkey') && !is_user_logged_in() && get_option("recaptcha4")) { $err .= verify_recaptcha(); }

if ($err == "") {
	if ($member_edit_page == "yes") {
		$new_user_id = $current_user->ID;
	} else {
		$new_user_id = wp_create_user( $user, $pass, $memberemail );
		//set an email hash so the user needs to validate his email in order to use the site
		$emailhash = md5($new_user_id.$user.$memberemail);
		update_user_meta( $new_user_id, "emailhash", $emailhash );
		//set user type
		update_option("escortid".$new_user_id, "member");

		//send email to member
		$body = _d('Hello',17).' '.$user.'<br /><br />
'._d('Before you can use the site you will need to validate your email address.',795).'
'._d('If you don\'t validate your email in the next 3 days your account will be deleted.',960).'<br /><br />
'._d('Please validate your email address by clicking the link bellow',1025).':
<a href="'.get_bloginfo('url').'/?ekey='.$emailhash.'">'.get_bloginfo('url').'/?ekey='.$emailhash.'</a>';
		dolce_email("", "", $memberemail, _d('Email validation link',1026)." ".get_option("email_sitename"), $body);

		wp_clear_auth_cookie(); //delete the cookies of the user if he is already logged in. for example if he is the admin
		wp_set_auth_cookie($new_user_id, true, ''); //add login cookies to the user so we can identify him
	}

	wp_update_user( array ('ID' => $new_user_id, 'nickname' => $membername, 'display_name' => $membername, 'user_url' => $website) );

	if ($member_edit_page == "yes") {
		//if the user is just changing the profile info then redirect him back to the profile page
		$ok = "ok";
	} else {
		//if the use is just registering then redirect him to the register page
		wp_redirect(get_permalink(get_option('member_register_page_id'))); exit;
	}
}
?>