<?php
/*
Template Name: Hide site sections
*/

global $current_user, $taxonomy_profile_name, $taxonomy_profile_name_plural;
get_currentuserinfo();
if (!current_user_can('level_10')) { wp_redirect(get_bloginfo("url")); exit; }

$err = ""; $ok = "";
if (isset($_POST['action']) && $_POST['action'] == 'hidesections') {
	$showheaderslider = (int)$_POST['showheaderslider'];
	$autoscrollheaderslider = (int)$_POST['autoscrollheaderslider'];
	$headerslideritems = (int)$_POST['headerslideritems'];
	$showheadersliderall = (int)$_POST['showheadersliderall'];
	$showheadersliderfront = (int)$_POST['showheadersliderfront'];
	$showheaderslideresccat = (int)$_POST['showheaderslideresccat'];
	$showheadersliderescprof = (int)$_POST['showheadersliderescprof'];
	$showheaderslideragprof = (int)$_POST['showheaderslideragprof'];
	$showheaderslidersearch = (int)$_POST['showheaderslidersearch'];
	$showheadersliderct = (int)$_POST['showheadersliderct'];
	$showheadersliderrev = (int)$_POST['showheadersliderrev'];
	$showheadersliderads = (int)$_POST['showheadersliderads'];

	$frontpageshowpremium = (int)$_POST['frontpageshowpremium'];
	$frontpageshowpremiumcols = (int)$_POST['frontpageshowpremiumcols'];
	if ($frontpageshowpremiumcols < 1) { $frontpageshowpremiumcols = "1"; }
	$frontpageshownormal = (int)$_POST['frontpageshownormal'];
	$frontpageshownormalcols = (int)$_POST['frontpageshownormalcols'];
	if ($frontpageshownormalcols < 1) { $frontpageshownormalcols = "1"; }
	$frontpageshowrev = (int)$_POST['frontpageshowrev'];
	$frontpageshowrevitems = (int)$_POST['frontpageshowrevitems'];
	if ($frontpageshowrevitems < 1) { $frontpageshowrevitems = "1"; }
	$frontpageshowrevchars = (int)$_POST['frontpageshowrevchars'];
	if ($frontpageshowrevchars < 1) { $frontpageshowrevchars = "100"; }

	$tos18 = (int)$_POST['tos18'];

	$quickescortsearch = (int)$_POST['quickescortsearch'];
	$hideunchedkedservices = (int)$_POST['hideunchedkedservices'];
	$hidelangdrpdwn = (int)$_POST['hidelangdrpdwn'];
	$hide1 = (int)$_POST['hide1'];
	$hide2 = (int)$_POST['hide2'];
	$hide3 = (int)$_POST['hide3'];
	$hide31 = (int)$_POST['hide31'];
	$hide4 = (int)$_POST['hide4'];
	$hide5 = (int)$_POST['hide5'];
	$hide10 = (int)$_POST['hide10'];
	$hide6 = (int)$_POST['hide6'];
	$hide7 = (int)$_POST['hide7'];
	$hide8 = (int)$_POST['hide8'];
	$hide9 = (int)$_POST['hide9'];


	$recaptcha1 = (int)$_POST['recaptcha1'];
	$recaptcha2 = (int)$_POST['recaptcha2'];
	$recaptcha3 = (int)$_POST['recaptcha3'];
	$recaptcha4 = (int)$_POST['recaptcha4'];
	$recaptcha_sitekey = preg_replace("/([^a-zA-Z0-9_-])/", "", $_POST['recaptcha_sitekey']);
	$recaptcha_secretkey = preg_replace("/([^a-zA-Z0-9_-])/", "", $_POST['recaptcha_secretkey']);

	if($recaptcha1 || $recaptcha2 || $recaptcha3 || $recaptcha4) {
		if(!$recaptcha_sitekey) {
			$err .= _d('Please enter a site key for reCAPTCHA.',1135)."<br />";
		}
		if(!$recaptcha_secretkey) {
			$err .= _d('Please enter your secret key for reCAPTCHA.',1136)."<br />";
		}
	}

	$locationdropdown = (int)$_POST['locationdropdown'];



	if($hide9 == "1") { $hide1 = "1"; } // if member registration is disabled also disable the reviews
	if($hide2 == "1" && $hide3 == "1" && $hide9 == "1") { $hide31 = "1"; } // if member registration is disabled also disable the reviews

	if(!$err) {
		update_option("showheaderslider", $showheaderslider);
		update_option("autoscrollheaderslider", $autoscrollheaderslider);
		update_option("headerslideritems", $headerslideritems);
		update_option("showheadersliderall", $showheadersliderall);
		update_option("showheadersliderfront", $showheadersliderfront);
		update_option("showheaderslideresccat", $showheaderslideresccat);
		update_option("showheadersliderescprof", $showheadersliderescprof);
		update_option("showheaderslideragprof", $showheaderslideragprof);
		update_option("showheaderslidersearch", $showheaderslidersearch);
		update_option("showheadersliderct", $showheadersliderct);
		update_option("showheadersliderrev", $showheadersliderrev);
		update_option("showheadersliderads", $showheadersliderads);

		update_option("frontpageshowpremium", $frontpageshowpremium);
		update_option("frontpageshowpremiumcols", $frontpageshowpremiumcols);
		update_option("frontpageshownormal", $frontpageshownormal);
		update_option("frontpageshownormalcols", $frontpageshownormalcols);
		update_option("frontpageshowrev", $frontpageshowrev);
		update_option("frontpageshowrevitems", $frontpageshowrevitems);
		update_option("frontpageshowrevchars", $frontpageshowrevchars);

		update_option("tos18", $tos18);
		update_option("quickescortsearch", $quickescortsearch);
		update_option("hideunchedkedservices", $hideunchedkedservices);
		update_option("hidelangdrpdwn", $hidelangdrpdwn);
		update_option("hide1", $hide1);
		update_option("hide2", $hide2);
		update_option("hide3", $hide3);
		update_option("hide31", $hide31);
		update_option("hide4", $hide4);
		update_option("hide5", $hide5);
		update_option("hide10", $hide10);
		update_option("hide6", $hide6);
		update_option("hide7", $hide7);
		update_option("hide8", $hide8);
		update_option("hide9", $hide9);

		update_option("recaptcha1", $recaptcha1);
		update_option("recaptcha2", $recaptcha2);
		update_option("recaptcha3", $recaptcha3);
		update_option("recaptcha4", $recaptcha4);
		update_option("recaptcha_sitekey", $recaptcha_sitekey);
		update_option("recaptcha_secretkey", $recaptcha_secretkey);

		update_option("locationdropdown", $locationdropdown);
		$ok = "ok";
	}
} else {
	$showheaderslider = get_option("showheaderslider");
	$autoscrollheaderslider = get_option("autoscrollheaderslider");
	$headerslideritems = get_option("headerslideritems");
	$showheadersliderall = get_option("showheadersliderall");
	$showheadersliderfront = get_option("showheadersliderfront");
	$showheaderslideresccat = get_option("showheaderslideresccat");
	$showheadersliderescprof = get_option("showheadersliderescprof");
	$showheaderslideragprof = get_option("showheaderslideragprof");
	$showheaderslidersearch = get_option("showheaderslidersearch");
	$showheadersliderct = get_option("showheadersliderct");
	$showheadersliderrev = get_option("showheadersliderrev");
	$showheadersliderads = get_option("showheadersliderads");

	$frontpageshowpremium = get_option("frontpageshowpremium");
	$frontpageshowpremiumcols = get_option("frontpageshowpremiumcols");
	$frontpageshownormal = get_option("frontpageshownormal");
	$frontpageshownormalcols = get_option("frontpageshownormalcols");
	$frontpageshowrev = get_option("frontpageshowrev");
	$frontpageshowrevitems = get_option("frontpageshowrevitems");
	$frontpageshowrevchars = get_option("frontpageshowrevchars");

	$manactivesc = get_option("manactivesc");
	$manactivag = get_option("manactivag");

	$tos18 = get_option("tos18");
	$quickescortsearch = get_option("quickescortsearch");
	$hideunchedkedservices = get_option("hideunchedkedservices");
	$hidelangdrpdwn = get_option("hidelangdrpdwn");
	$hide1 = get_option("hide1");
	$hide2 = get_option("hide2");
	$hide3 = get_option("hide3");
	$hide31 = get_option("hide31");
	$hide4 = get_option("hide4");
	$hide5 = get_option("hide5");
	$hide10 = get_option("hide10");
	$hide6 = get_option("hide6");
	$hide7 = get_option("hide7");
	$hide8 = get_option("hide8");
	$hide9 = get_option("hide9");

	$recaptcha1 = get_option("recaptcha1");
	$recaptcha2 = get_option("recaptcha2");
	$recaptcha3 = get_option("recaptcha3");
	$recaptcha4 = get_option("recaptcha4");
	$recaptcha_sitekey = get_option("recaptcha_sitekey");
	$recaptcha_secretkey = get_option("recaptcha_secretkey");

	$locationdropdown = get_option("locationdropdown");
}

get_header(); ?>

		<div class="contentwrapper">
		<div class="body">
        	<div class="bodybox">
				<h3 class="settingspagetitle l"><?php _de('Hide or show site sections',800); ?></h3>
                <div class="clear"></div>
				<?php if ($err) { echo "<div class=\"err rad3\">$err</div>"; } ?>
				<?php if ($ok) { echo "<div class=\"ok rad3\">"._d('Your settings have been saved',168)."</div>"; } ?>
				<form action="<?php echo get_permalink(get_the_ID()); ?>" method="post" class="form-styling">
					<input type="hidden" name="action" value="hidesections" />

					<div class="form-label">
						<label><?php _de('Show header slider?',178); ?></label>
					</div>
					<div class="form-input">
						<label for="showheaderslideryes"><input type="radio" name="showheaderslider" value="1" id="showheaderslideryes"<?php if($showheaderslider == "1") { echo ' checked'; } ?> /> <?php _de('Yes',156); ?></label>
						<label for="showheadersliderno"><input type="radio" name="showheaderslider" value="2" id="showheadersliderno"<?php if($showheaderslider == "2") { echo ' checked'; } ?> /> <?php _de('No',157); ?></label><br />
					</div> <!-- header slider --> <div class="formseparator"></div>

					<div class="form-label">
						<label><?php _de('Scroll the header slider automatically?',1262); ?></label>
					</div>
					<div class="form-input">
						<label for="autoscrollheaderslideryes"><input type="radio" name="autoscrollheaderslider" value="1" id="autoscrollheaderslideryes"<?php if($autoscrollheaderslider == "1") { echo ' checked'; } ?> /> <?php _de('Yes',156); ?></label>
						<label for="autoscrollheadersliderno"><input type="radio" name="autoscrollheaderslider" value="2" id="autoscrollheadersliderno"<?php if($autoscrollheaderslider == "2") { echo ' checked'; } ?> /> <?php _de('No',157); ?></label><br />
					</div> <!-- header slider --> <div class="formseparator"></div>

					<div class="form-label">
						<label><?php _de('Number of %s to show in slider',179,$taxonomy_profile_name_plural); ?></label>
                    </div>
					<div class="form-input">
						<input type="text" name="headerslideritems" id="headerslideritems" class="input" value="<?php echo $headerslideritems; ?>" />
					</div> <!-- --> <div class="formseparator"></div>

					<div class="form-label">
    					<label><?php _de('Where to show the slider?',181); ?></label>
				    </div>
					<div class="form-input">
					    <label for="showheadersliderall">
			        		<input type="checkbox" name="showheadersliderall" value="1" id="showheadersliderall"<?php if($showheadersliderall == "1") { echo ' checked'; } ?> /> 
			    	        <?php _de('All site pages',182); ?>
						</label>
						<small><i>!</i> <?php _de('this overwrites any settings below',183); ?></small>
						<div class="clear10"></div>
					    <label for="showheadersliderfront">
				        	<input type="checkbox" name="showheadersliderfront" value="1" id="showheadersliderfront"<?php if($showheadersliderfront == "1") { echo ' checked'; } ?> /> 
				            <?php _de('On front page',184); ?>
							</label><div class="clear5"></div>
					    <label for="showheaderslideresccat">
				        	<input type="checkbox" name="showheaderslideresccat" value="1" id="showheaderslideresccat"<?php if($showheaderslideresccat == "1") { echo ' checked'; } ?> /> 
				            <?php _de('On %s category pages',185,$taxonomy_profile_name); ?>
						</label><div class="clear5"></div>
					    <label for="showheadersliderescprof">
			    	    	<input type="checkbox" name="showheadersliderescprof" value="1" id="showheadersliderescprof"<?php if($showheadersliderescprof == "1") { echo ' checked'; } ?> /> 
				            <?php _de('On %s profile pages',186,$taxonomy_profile_name); ?>
						</label><div class="clear5"></div>
					    <label for="showheaderslideragprof">
				        	<input type="checkbox" name="showheaderslideragprof" value="1" id="showheaderslideragprof"<?php if($showheaderslideragprof == "1") { echo ' checked'; } ?> /> 
				            <?php _de('On %s profile pages',186,$taxonomy_agency_name); ?>
						</label><div class="clear5"></div>
					    <label for="showheaderslidersearch">
				        	<input type="checkbox" name="showheaderslidersearch" value="1" id="showheaderslidersearch"<?php if($showheaderslidersearch == "1") { echo ' checked'; } ?> /> 
				            <?php _de('On search pages',188); ?>
						</label><div class="clear5"></div>
					    <label for="showheadersliderct">
				        	<input type="checkbox" name="showheadersliderct" value="1" id="showheadersliderct"<?php if($showheadersliderct == "1") { echo ' checked'; } ?> /> 
				            <?php _de('On city tours page',189); ?>
						</label><div class="clear5"></div>
					    <label for="showheadersliderrev">
				        	<input type="checkbox" name="showheadersliderrev" value="1" id="showheadersliderrev"<?php if($showheadersliderrev == "1") { echo ' checked'; } ?> /> 
				            <?php _de('On the reviews pages',190); ?>
						</label><div class="clear5"></div>
				    	<label for="showheadersliderads">
			        		<input type="checkbox" name="showheadersliderads" value="1" id="showheadersliderads"<?php if($showheadersliderads == "1") { echo ' checked'; } ?> /> 
				            <?php _de('On the classified ads pages',191); ?>
						</label>
				    </div> <!-- --> <div class="formseparator"></div>


					<div class="clear10"></div>
					<fieldset class="fieldset rad5">
						<legend><?php _de('What content to show on the front page?',192); ?></legend>

						<div class="form-label">
					    	<label><?php _de('Premium %s content box',193,$taxonomy_profile_name_plural); ?></label>
					    </div>
						<div class="form-input">
							<select name="frontpageshowpremium" id="frontpageshowpremium">
								<option value="1"<?php if($frontpageshowpremium == "1") { echo ' selected'; } ?>>Yes</option>
								<option value=""<?php if(!$frontpageshowpremium) { echo ' selected'; } ?>>No</option>
							</select><div class="clear10"></div>

							<label><?php _de('Number of columns to show',194); ?></label>
					        <small><i>!</i> <?php _de('each column has 5 %s',195,$taxonomy_profile_name_plural); ?></small>
					        <input type="text" name="frontpageshowpremiumcols" id="frontpageshowpremiumcols" class="input" value="<?php echo $frontpageshowpremiumcols; ?>" />
						</div> <!-- show premium --> <div class="formseparator"></div>

						<div class="form-label">
					        <label><?php _de('Normal %s content box',196,$taxonomy_profile_name_plural); ?></label>
					 	</div>
						<div class="form-input">
							<select name="frontpageshownormal" id="frontpageshownormal">
								<option value="1"<?php if($frontpageshownormal == "1") { echo ' selected'; } ?>>Yes</option>
								<option value=""<?php if(!$frontpageshownormal) { echo ' selected'; } ?>>No</option>
							</select><div class="clear10"></div>

				    	    <?php _de('Number of columns to show',197); ?>:
				    	    <small><i>!</i> <?php _de('each column has 5 %s',195,$taxonomy_profile_name_plural); ?></small>
				    	    <input type="text" name="frontpageshownormalcols" id="frontpageshownormalcols" class="input" value="<?php echo $frontpageshownormalcols; ?>" />
						</div> <!-- show normal --> <div class="formseparator"></div>
							
						<div class="form-label">
					        <label for="frontpageshowrev"><?php _de('Reviews content box',198); ?></label>
					    </div>
						<div class="form-input">
							<select name="frontpageshowrev" id="frontpageshowrev">
								<option value="1"<?php if($frontpageshowrev == "1") { echo ' selected'; } ?>>Yes</option>
								<option value=""<?php if(!$frontpageshowrev) { echo ' selected'; } ?>>No</option>
							</select><div class="clear5"></div>

					        <?php _de('Number of reviews to show',199); ?>:<div class="clear10"></div>
					        <input type="text" name="frontpageshowrevitems" id="frontpageshowrevitems" class="input" value="<?php echo $frontpageshowrevitems; ?>" /><div class="clear10"></div>

					        <?php _de('How many characters to show from each review?',200); ?><div class="clear"></div>
				    	    <input type="text" name="frontpageshowrevchars" id="frontpageshowrevchars" class="input" value="<?php echo $frontpageshowrevchars; ?>" />
					    </div> <!-- show reviews -->
					</fieldset> <!-- what to show on the front page --> <div class="formseparator"></div>

				    <div class="form-label">
				    	<label><?php _de('Show agreement/disclaimer when someone visits the site for the first time?',205); ?></label>
				    </div>
					<div class="form-input">
					    <label for="tos18yes"><input type="radio" name="tos18" value="1" id="tos18yes"<?php if($tos18 == "1") { echo ' checked'; } ?> /> <?php _de('Yes',156); ?></label>
				    	<label for="tos18no"><input type="radio" name="tos18" value="2" id="tos18no"<?php if($tos18 == "2") { echo ' checked'; } ?> /> <?php _de('No',157); ?></label>
						<small><i>!</i> <?php _de('If you want to change the text from the disclaimer then edit the file',206); ?> "<u>footer-tos-18years-agreement-overlay.php</u>" <?php _de('from your theme directory',207); ?>.</small>
				    </div> <!-- --> <div class="formseparator"></div>

				    <div class="form-label">
				    	<label><?php _de('Show "Quick %s Search" widget in right sidebar?',208,ucwords($taxonomy_profile_name)); ?></label>
				    </div>
					<div class="form-input">
					    <label for="quickescortsearchyes"><input type="radio" name="quickescortsearch" value="1" id="quickescortsearchyes"<?php if($quickescortsearch == "1") { echo ' checked'; } ?> /> <?php _de('Yes',156); ?></label>
				    	<label for="quickescortsearchno"><input type="radio" name="quickescortsearch" value="2" id="quickescortsearchno"<?php if($quickescortsearch == "2") { echo ' checked'; } ?> /> <?php _de('No',157); ?></label>
				    </div> <!-- --> <div class="formseparator"></div>

				    <div class="form-label">
				    	<label><?php _de('Show unchecked services in %s profile pages?',801,$taxonomy_profile_name); ?></label>
				    </div>
					<div class="form-input">
					    <label for="hideunchedkedservicesyes"><input type="radio" name="hideunchedkedservices" value="1" id="hideunchedkedservicesyes"<?php if($hideunchedkedservices == "1") { echo ' checked'; } ?> /> <?php _de('Yes',156); ?></label>
				    	<label for="hideunchedkedservicesno"><input type="radio" name="hideunchedkedservices" value="2" id="hideunchedkedservicesno"<?php if($hideunchedkedservices == "2") { echo ' checked'; } ?> /> <?php _de('No',157); ?></label>
				    </div> <!-- --> <div class="formseparator"></div>

				    <div class="form-label">
				    	<label><?php _de('Show language dropdown in header?',924); ?></label>
				    </div>
					<div class="form-input">
					    <label for="hidelangdrpdwnyes"><input type="radio" name="hidelangdrpdwn" value="1" id="hidelangdrpdwnyes"<?php if($hidelangdrpdwn == "1") { echo ' checked'; } ?> /> <?php _de('Yes',156); ?></label>
				    	<label for="hidelangdrpdwnno"><input type="radio" name="hidelangdrpdwn" value="2" id="hidelangdrpdwnno"<?php if($hidelangdrpdwn == "2") { echo ' checked'; } ?> /> <?php _de('No',157); ?></label>
				    </div> <!-- --> <div class="formseparator"></div>

				    <div class="form-label">
    					<label><?php _de('What sections do you want to hide from the site?',802); ?></label>
				    </div>
					<div class="form-input">
					    <label for="hide1">
			        		<input type="checkbox" name="hide1" value="1" id="hide1"<?php if($hide1 == "1") { echo ' checked'; } ?> />
							<?php _de('Reviews',803); ?>
						</label><div class="clear5"></div>
					    <label for="hide2">
			        		<input type="checkbox" name="hide2" value="1" id="hide2"<?php if($hide2 == "1") { echo ' checked'; } ?> />
							<?php _de('Independent %s registration',804,$taxonomy_profile_name); ?>
						</label><div class="clear5"></div>
					    <label for="hide3">
			        		<input type="checkbox" name="hide3" value="1" id="hide3"<?php if($hide3 == "1") { echo ' checked'; } ?> />
							<?php _de('%s registration',805,ucfirst($taxonomy_agency_name)); ?>
						</label><div class="clear5"></div>
					    <label for="hide31">
			        		<input type="checkbox" name="hide31" value="1" id="hide31"<?php if($hide31 == "1") { echo ' checked'; } ?> />
							<?php _de('Register/Login header links',844); ?>
						</label><div class="clear5"></div>
					    <label for="hide4">
			        		<input type="checkbox" name="hide4" value="1" id="hide4"<?php if($hide4 == "1") { echo ' checked'; } ?> />
							<?php _de('Blacklisted %s',806,$taxonomy_profile_name_plural); ?>
						</label><div class="clear5"></div>
					    <label for="hide5">
			        		<input type="checkbox" name="hide5" value="1" id="hide5"<?php if($hide5 == "1") { echo ' checked'; } ?> />
							<?php _de('Blacklisted clients',807); ?>
						</label><div class="clear5"></div>
					    <label for="hide10">
			        		<input type="checkbox" name="hide10" value="1" id="hide10"<?php if($hide10 == "1") { echo ' checked'; } ?> />
							<?php _de('Our Blog',1125); ?>
						</label><div class="clear5"></div>
					    <label for="hide6">
			        		<input type="checkbox" name="hide6" value="1" id="hide6"<?php if($hide6 == "1") { echo ' checked'; } ?> />
							<?php _de('Classified ads',294); ?>
						</label><div class="clear5"></div>
					    <label for="hide7">
			        		<input type="checkbox" name="hide7" value="1" id="hide7"<?php if($hide7 == "1") { echo ' checked'; } ?> />
							<?php _de('Verified status',809); ?>
						</label><div class="clear5"></div>
					    <label for="hide8">
			        		<input type="checkbox" name="hide8" value="1" id="hide8"<?php if($hide8 == "1") { echo ' checked'; } ?> />
							<?php _de('%s on tour',810,ucfirst($taxonomy_profile_name_plural)); ?>
						</label><div class="clear5"></div>
					    <label for="hide9">
			        		<input type="checkbox" name="hide9" value="1" id="hide9"<?php if($hide9 == "1") { echo ' checked'; } ?> />
							<?php _de('Member registration',160); ?>
						</label>
						<small><i>!</i> <?php _de('Disabling member registration will also disable the reviews',1073); ?></small>
				    </div> <!-- --> <div class="formseparator"></div>

					<script type="text/javascript">
						jQuery(document).ready(function($) {
							check_recaptcha_fields();

							$('.recaptcha input:checkbox').on('change', function() {
								check_recaptcha_fields();
							});

							function check_recaptcha_fields() {
								if ($(".recaptcha input:checkbox:checked").length) {
								    $('.recaptcha-keys').slideDown('fast');
								} else {
								    $('.recaptcha-keys').slideUp('fast');
								}
							}
						});
					</script>
				    <div class="form-label">
    					<label><?php _de('Add a reCAPTCHA to these forms to prevent spam',1132); ?>:</label>
				    </div>
					<div class="form-input recaptcha">
					    <label for="recaptcha1">
			        		<input type="checkbox" name="recaptcha1" value="1" id="recaptcha1"<?php if($recaptcha1 == "1") { echo ' checked'; } ?> />
							<?php _de('Contact form',1133); ?>
						</label><div class="clear5"></div>
					    <label for="recaptcha2">
			        		<input type="checkbox" name="recaptcha2" value="1" id="recaptcha2"<?php if($recaptcha2 == "1") { echo ' checked'; } ?> />
							<?php _de('Independent %s registration',804,$taxonomy_profile_name); ?>
						</label><div class="clear5"></div>
					    <label for="recaptcha3">
			        		<input type="checkbox" name="recaptcha3" value="1" id="recaptcha3"<?php if($recaptcha3 == "1") { echo ' checked'; } ?> />
							<?php _de('%s registration',805,ucfirst($taxonomy_agency_name)); ?>
						</label><div class="clear5"></div>
					    <label for="recaptcha4">
			        		<input type="checkbox" name="recaptcha4" value="1" id="recaptcha4"<?php if($recaptcha4 == "1") { echo ' checked'; } ?> />
							<?php _de('Member registration',160); ?>
						</label>

						<div class="recaptcha-keys hide">
							<div class="clear20"></div>
							<small><i>!</i> <a href="https://www.google.com/recaptcha/" target="_blank"><u><?php _de('Click here to register for reCAPTCHA for free',1134); ?></u></a></small>
	                    	Site key:<br />
							<input type="text" name="recaptcha_sitekey" id="recaptcha_sitekey" class="input longinput" value="<?php echo $recaptcha_sitekey; ?>" /><div class="clear10"></div>
	                    	Secret key:<br />
							<input type="text" name="recaptcha_secretkey" id="recaptcha_secretkey" class="input longinput" value="<?php echo $recaptcha_secretkey; ?>" /><div class="clear10"></div>
						</div>
				    </div> <!-- --> <div class="formseparator"></div>

				    <div class="form-label">
				    	<label><?php _de('Show registration city/state as a dropdown list?',1224); ?></label>
				    </div>
					<div class="form-input">
					    <label for="locationdropdownyes"><input type="radio" name="locationdropdown" value="1" id="locationdropdownyes"<?php if($locationdropdown == "1") { echo ' checked'; } ?> /> <?php _de('Yes',156); ?></label>
				    	<label for="locationdropdownno"><input type="radio" name="locationdropdown" value="2" id="locationdropdownno"<?php if($locationdropdown == "2") { echo ' checked'; } ?> /> <?php _de('No',157); ?></label>
				    	<small><i>!</i> <?=_d('If you activate this you will need to add the city list manually',1225)?></small>
				    	<small><i>!</i> <?=_d('To add cities click the link "Add countries" from the admin menu',1226)?></small>
				    </div> <!-- --> <div class="formseparator"></div>

					<div class="center"><input type="submit" name="submit" value="<?php _de('Save settings',1008); ?>" class="bluebutton rad3" /></div> <!--center-->
				</form>
				<div class="clear"></div>
			</div> <!-- BODY BOX -->
		</div> <!-- BODY -->
        </div> <!-- contentwrapper -->

		<?php get_sidebar("left"); ?>
		<?php get_sidebar("right"); ?>
    	<div class="clear"></div>
<?php get_footer(); ?>