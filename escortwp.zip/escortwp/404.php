<?php
get_header();
flush_rewrite_rules('false');
?>
<div class="center">
	<div class="clear30"></div>
	<h1>404</h1>
	<h2>page not found</h2>
	<div class="clear30"></div>
</div>

<?php get_footer(); ?>