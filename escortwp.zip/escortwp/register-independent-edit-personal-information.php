<?php
/*
Template Name: Register Independent - Edit Personal Information
*/

global $current_user, $taxonomy_profile_url, $taxonomy_location_url;
get_currentuserinfo();
if (!is_user_logged_in() || get_option("escortid".$current_user->ID) != $taxonomy_profile_url) { wp_redirect(get_bloginfo("url")); exit; }


	$err = "";
	$ok = "";
if (isset($_POST['action']) && $_POST['action'] == 'register') {
	include (get_template_directory() . '/register-independent-personal-info-process.php');
} else {
	$escort_post_id = get_option("escortpostid".$current_user->ID);
	$escort = get_post($escort_post_id);

	$aboutyou = $escort->post_content;
	$youremail = $current_user->user_email;
	$yourname = $current_user->display_name;

	$phone = get_post_meta($escort_post_id, "phone", true);
	$escortemail = get_post_meta($escort_post_id, "escortemail", true);
	$website = get_post_meta($escort_post_id, "website", true);

	if(get_option('locationdropdown') == "1") {
		$country = get_post_meta($escort_post_id, "country", true);
		if(showfield('state')) {
			$state = get_post_meta($escort_post_id, "state", true);
		}
		$city_id = get_post_meta($escort_post_id, "city", true);
		$city = $city_id;
	} else {
		$country = get_post_meta($escort_post_id, "country", true);
		if(showfield('state')) {
			$state = get_term(get_post_meta($escort_post_id, "state", true), $taxonomy_location_url);
			$state = $state->name;
		}
		$city_id = get_post_meta($escort_post_id, "city", true);
		$city = get_term($city_id, $taxonomy_location_url);
		$city = $city->name;
	}

	$gender = get_post_meta($escort_post_id, "gender", true);
	$birthday = get_post_meta($escort_post_id, "birthday", true);
	$birthday = explode("-", $birthday);
	$dateyear = $birthday[0];
	$datemonth = $birthday[1];
	$dateday = $birthday[2];
	$ethnicity = get_post_meta($escort_post_id, "ethnicity", true);
	$haircolor = get_post_meta($escort_post_id, "haircolor", true);
	$hairlength = get_post_meta($escort_post_id, "hairlength", true);
	$bustsize = get_post_meta($escort_post_id, "bustsize", true);
	$height = get_post_meta($escort_post_id, "height", true);
	$weight = get_post_meta($escort_post_id, "weight", true);
	$build = get_post_meta($escort_post_id, "build", true);
	$looks = get_post_meta($escort_post_id, "looks", true);
	$smoker = get_post_meta($escort_post_id, "smoker", true);
	$availability = get_post_meta($escort_post_id, "availability", true);
	$language1 = get_post_meta($escort_post_id, "language1", true);
	$language1level = get_post_meta($escort_post_id, "language1level", true);
	$language2 = get_post_meta($escort_post_id, "language2", true);
	$language2level = get_post_meta($escort_post_id, "language2level", true);
	$language3 = get_post_meta($escort_post_id, "language3", true);
	$language3level = get_post_meta($escort_post_id, "language3level", true);
	$rate30min_incall = get_post_meta($escort_post_id, "rate30min_incall", true);
	$rate1h_incall = get_post_meta($escort_post_id, "rate1h_incall", true);
	$rate2h_incall = get_post_meta($escort_post_id, "rate2h_incall", true);
	$rate3h_incall = get_post_meta($escort_post_id, "rate3h_incall", true);
	$rate6h_incall = get_post_meta($escort_post_id, "rate6h_incall", true);
	$rate12h_incall = get_post_meta($escort_post_id, "rate12h_incall", true);
	$rate24h_incall = get_post_meta($escort_post_id, "rate24h_incall", true);

	$rate30min_outcall = get_post_meta($escort_post_id, "rate30min_outcall", true);
	$rate1h_outcall = get_post_meta($escort_post_id, "rate1h_outcall", true);
	$rate2h_outcall = get_post_meta($escort_post_id, "rate2h_outcall", true);
	$rate3h_outcall = get_post_meta($escort_post_id, "rate3h_outcall", true);
	$rate6h_outcall = get_post_meta($escort_post_id, "rate6h_outcall", true);
	$rate12h_outcall = get_post_meta($escort_post_id, "rate12h_outcall", true);
	$rate24h_outcall = get_post_meta($escort_post_id, "rate24h_outcall", true);
	$services = get_post_meta($escort_post_id, "services");
	$services = $services[0];
	$extraservices = get_post_meta($escort_post_id, "extraservices", true);
	$secret = get_post_meta($escort_post_id, "secret", true);
	$upload_folder = get_post_meta($escort_post_id, "upload_folder", true);
	$education = get_post_meta($escort_post_id,'education', true);
	$sports = get_post_meta($escort_post_id,'sports', true);
	$hobbies = get_post_meta($escort_post_id,'hobbies', true);
	$zodiacsign = get_post_meta($escort_post_id,'zodiacsign', true);
	$sexualorientation = get_post_meta($escort_post_id,'sexualorientation', true);
	$occupation = get_post_meta($escort_post_id,'occupation', true);
} // if is user logged in
?>
<?php get_header(); ?>

		<div class="contentwrapper">
		<div class="body">
        	<div class="bodybox registerform">
            	<h3><?php _de('Edit my Profile',542); ?></h3>
				<?php
					if ($ok) echo "<div class=\"ok rad3\">"._d('Profile updated',471)."</div>";
					include (get_template_directory() . '/register-independent-personal-information-form.php');
				?>
                <div class="clear"></div>
            </div> <!-- BODY BOX -->
            <div class="clear"></div>
        </div> <!-- BODY -->
        </div> <!-- contentwrapper -->

		<?php get_sidebar("left"); ?>
		<?php get_sidebar("right"); ?>
    	<div class="clear"></div>

<?php get_footer(); ?>