<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }

$taxonomy_profile_name = get_option("taxonomy_profile_name");
$taxonomy_profile_name_plural = get_option("taxonomy_profile_name_plural");
$taxonomy_profile_url = get_option("taxonomy_profile_url");
$settings_theme_genders = get_option("settings_theme_genders");
$taxonomy_agency_name = get_option("taxonomy_agency_name");
$taxonomy_agency_name_plural = get_option("taxonomy_agency_name_plural");
$taxonomy_agency_url = get_option("taxonomy_agency_url");
$taxonomy_location_url = get_option("taxonomy_location_url");

/*
[key] 'inputname'
[0] 'name'
[1] 'showinreg'
[2] 'mandatory'
[3] 'useinsearch'

LEGEND for showinreg, mandatory, useinsearch
1 = yes
2 = no
3 = yes, can't edit
4 = no, can't edit
*/

$escortregfields = array(
				'user' => array(_d('Username',409),'3','3','4'),
				'pass' => array(_d('Password',411),'3','3','4'),
				'youremail' => array(_d('Your Email',153),'3','3','4'),
				'yourname' => array(_d('Name',70),'3','3','1'),
				'phone' => array(_d('Phone',49),'1','1','4'),
				'website' => array(_d('Website',368),'1','2','4'),
				'country' => array(_d('Country',80),'3','3','3'),
				'state' => array(_d('State',76),'2','3','3'),
				'city' => array(_d('City',81),'3','3','3'),
				'gender' => array(_d('Gender',391),'3','3','1'),
				'birth' => array(_d('Date of birth',416),'3','3','4'),
				'ethnicity' => array(_d('Ethnicity',392),'1','1','1'),
				'haircolor' => array(_d('Hair Color',403),'1','1','1'),
				'hairlength' => array(_d('Hair length',404),'1','1','1'),
				'bustsize' => array(_d('Bust size',405),'1','1','1'),
				'height' => array(_d('Height',406),'1','1','1'),
				'weight' => array(_d('Weight',413),'1','1','1'),
				'build' => array(_d('Build',407),'1','1','1'),
				'looks' => array(_d('Looks',408),'1','1','1'),
				'availability' => array(_d('Availability',394),'1','1','1'),
				'smoker' => array(_d('Smoker',395),'1','1','1'),
				'aboutyou' => array(_d('About you',433),'1','1','4'),
				'education' => array(_d('Education',434),'1','2','4'),
				'sports' => array(_d('Sports',435),'1','2','4'),
				'hobbies' => array(_d('Hobbies',436),'1','2','4'),
				'zodiacsign' => array(_d('Zodiac sign',437),'1','2','4'),
				'sexualorientation' => array(_d('Sexual orientation',438),'1','2','4'),
				'occupation' => array(_d('Occupation',439),'1','2','4'),
				'language' => array(_d('Languages spoken',440),'1','2','4'),
				'rates' => array(_d('Rates',396),'1','1','1'),
				'services' => array(_d('Services',399),'1','1','1'),
				'extraservices' => array(_d('Extra services',449),'1','2','4')
			);
$height_a = array(
		"1" => "128",
		"2" => "134",
		"3" => "140",
		"4" => "146",
		"5" => "152",
		"6" => "155",
		"7" => "158",
		"8" => "162",
		"9" => "165",
		"10" => "168",
		"11" => "171",
		"12" => "174",
		"13" => "177",
		"14" => "180",
		"15" => "183",
		"16" => "189",
		"17" => "195",
		"18" => "201",
		"19" => "207",
		"20" => "213"
	);
//data for the register fields
$gender_a = array(
	"1" => _d('Female',25),
	"2" => _d('Male',26),
	"3" => _d('Couple',1112),
	"4" => _d('Gay',1113),
	"5" => _d('Transsexual',1114)
);
$ethnicity_a = array("1" => _d('Latin',214), "2" => _d('Caucasian',215), "3" => _d('Black',216), "4" => _d('White',217), "5" => _d('MiddleEast',218), "6" => _d('Asian',219), "7" => _d('Indian',220), "8" => _d('Aborigine',221), "9" => _d('Native American',222), "10" => _d('Other',223));
$haircolor_a = array("1" => _d('Black',224), "2" => _d('Blonde',225), "3" => _d('Brown',226), "4" => _d('Brunette',227), "5" => _d('Chestnut',228), "6" => _d('Auburn',229), "7" => _d('Dark-blonde',230), "8" => _d('Golden',231), "9" => _d('Red',232), "10" => _d('Grey',233), "11" => _d('Silver',234), "12" => _d('White',235), "14" => _d('Other',237));
$hairlength_a = array("1" => _d('Bald',238), "2" => _d('Short',239), "3" => _d('Shoulder',240), "4" => _d('Long',241), "5" => _d('Very Long',242));
$bustsize_a = array("1" => _d('Very small',243), "2" => _d('Small(A)',244), "3" => _d('Medium(B)',245), "4" => _d('Large(C)',246), "5" => _d('Very Large(D)',247), "6" => _d('Enormous(E+)',248));
$build_a = array("1" => _d('Skinny',249), "2" => _d('Slim',250), "3" => _d('Regular',251), "4" => _d('Curvy',252), "5" => _d('Fat',253));
$looks_a = array("1" => _d('Nothing Special',254), "2" => _d('Average',255), "3" => _d('Sexy',256), "4" => _d('Ultra Sexy',257));
$smoker_a = array("1" => _d('Yes',156), "2" => _d('No',157));
$availability_a = array("1" => _d('Incall',258), "2" => _d('Outcall',259));
$languagelevel_a = array("1" => _d('Minimal',260), "2" => _d('Conversational',261), "3" => _d('Fluent',262));
$services_a = array(
	"1" => _d('OWO (Oral without condom)',263), 
	"2" => _d('O-Level (Oral sex)',264), 
	"3" => _d('CIM (Come in mouth)',265), 
	"4" => _d('COF (Come on face)',266), 
	"5" => _d('COB (Come on body)',267), 
	"6" => _d('Swallow',268), 
	"7" => _d('DFK (Deep french kissing)',269), 
	"8" => _d('A-Level (Anal sex)',270),  
	"9" => _d('Anal Rimming (Licking anus)',271), 
	"10" => _d('69 (69 sex position)',272),
	"11" => _d('Striptease/Lapdance',273), 
	"12" => _d('Erotic massage',274), 
	"13" => _d('Golden shower',275), 
	"14" => _d('Couples',276), 
	"15" => _d('GFE (Girlfriend experience)',277), 
	"16" => _d('Threesome',278), 
	"17" => _d('Foot fetish',279), 
	"18" => _d('Sex toys',280), 
	"19" => _d('Extraball (Having sex multiple times)',281), 
	"20" => _d('Domination',282), 
	"21" => _d('LT (Long Time; Usually overnight)',283)
);

$currency_a = array(
	//currency code, currency name, currency symbol(show in front or after the amount)
	"8" => array("EUR", "Euro", "", "&euro;"),
	"22" => array("USD", "U.S. Dollar", "$", ""),
	"1" => array("AUD", "Australian Dollar", "$", ""),
	"2" => array("BGN", "Bulgarian Lev", "", "&#1083;&#1074;"),
	"3" => array("CAD", "Canadian Dollar", "", "$"),
	"4" => array("CHF", "Swiss Franc", "", "fr"),
	"5" => array("CZK", "Czech Koruna", "", "K&#269;"),
	"6" => array("DKK", "Danish Krone", "", "kr"),
	"9" => array("GBP", "Pound Sterling", "&pound;", ""),
	"10" => array("HKD", "Hong Kong Dollar", "HK$", ""),
	"11" => array("HUF", "Hungarian Forint", "", "Ft"),
	"15" => array("MKD", "Macedonian Denar", "", "&#1076;&#1077;&#1085;"),
	"14" => array("MYR", "Malaysian Ringgit", "RM", ""),
	"16" => array("NOK", "Norwegian Krone", "", "kr"),
	"17" => array("NZD", "New Zealand Dollar", "$", ""),
	"18" => array("PLN", "Polish Zloty", "", "z&#322;"),
	"19" => array("RON", "Romanian New Leu", "", "lei"),
	"20" => array("SEK", "Swedish Krona", "", "kr")
);

$payment_options_a = array(
	/*
	[0] Name
	[1] Payza ap_timeunit
	[2] PayPal t3
	[3] Payza ap_periodlength & PayPal p3
	[4] Number of days (CCBill)
	*/
	"1" => array(_d("1 day",823), "Day", "D", "1", "1"),
	"2" => array(_d("1 week",824), "Week", "W", "1", "7"),
	"3" => array(_d("2 weeks",825), "Week", "W", "2", "14"),
	"4" => array(_d("3 weeks",826), "Week", "W", "3", "21"),
	"5" => array(_d("1 month",827), "Month", "M", "1", "30"),
	"6" => array(_d("2 months",828), "Month", "M", "2", "60"),
	"7" => array(_d("3 months",829), "Month", "M", "3", "90"),
	"8" => array(_d("4 months",830), "Month", "M", "4", "120"),
	"9" => array(_d("5 months",831), "Month", "M", "5", "150"),
	"10" => array(_d("6 months",832), "Month", "M", "6", "180"),
	"11" => array(_d("7 months",833), "Month", "M", "7", "210"),
	"12" => array(_d("8 months",834), "Month", "M", "8", "240"),
	"13" => array(_d("9 months",835), "Month", "M", "9", "270"),
	"14" => array(_d("10 months",836), "Month", "M", "10", "300"),
	"15" => array(_d("11 months",837), "Month", "M", "11", "330"),
	"16" => array(_d("1 year",838), "Year", "Y", "1", "365"),
	"17" => array(_d("2 years",839), "Year", "Y", "2", "730")
);


$thumb_sizes = array( // w and h
		'1' => array(183, 263), // thumbnail size for listings
		'2' => array(250, 370), // header slider size
		'3' => array(110, 160), // thumbnail size in profile pages
		'4' => array(400, 600), // thumbnail size in profile pages for mobile
	);

add_image_size( 'listings-thumb', 183, 263, array( 'center', 'top' ) ); // thumbnail size for listings
add_image_size( 'header-slider', 250, 370, array( 'center', 'top' ) ); // header slider size
add_image_size( 'profile-thumb', 280, 415, array( 'center', 'top' ) ); // thumbnail size in profile pages
add_image_size( 'profile-thumb-mobile', 400 ); // thumbnail size in profile pages for mobile
add_image_size( 'main-image-thumb', 312, 1000 ); // thumbnail size in profile pages for mobile
?>