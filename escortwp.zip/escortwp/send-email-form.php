<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }
?>
<div class="escortcontact rad5 hide"<?php if ($err && $_POST['action'] == "contactform") { echo ' style="display: block;"'; } ?>>
	<?php closebtn(); ?>
	<?php if (is_user_logged_in()) { ?>
	    <form action="<?php echo get_permalink(get_the_ID()); ?>#contactform" method="post" class="form-styling">
		    <input type="hidden" name="action" value="contactform" />
			<input type="text" name="emails" value="" class="hide" />
			<div class="form-label col100">
				<label for="contactformmess"><?php _de('Message',369); ?></label>
			</div>
			<div class="form-input col100">
				<textarea name="contactformmess" id="contactformmess" class="textarea col100" cols="8" rows="7"><?php echo $contactformmess; ?></textarea>
			</div> <!-- --> <div class="formseparator"></div>

		    <input type="submit" name="submit" value="<?php _de('Send message',616); ?>" class="bluebutton rad3" />
	    </form>
	<?php } else { ?>
		<div class="err rad3"><?php _de('You need to',617); ?> <a href="<?php echo get_permalink(get_option('main_reg_page_id')); ?>"><?php _de('register',618); ?></a> <?php _de('or',619); ?> <a href="<?php echo wp_login_url(get_permalink()); ?>"><?php _de('login',620); ?></a> <?php _de('to be able to send messages',621); ?></div>
	<?php } ?>
</div> <!-- contact form -->