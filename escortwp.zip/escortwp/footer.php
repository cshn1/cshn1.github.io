<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }

global $taxonomy_profile_name;
?>
	<div class="clear10"></div>

	<?php if ( is_active_sidebar('widget-footer') || current_user_can('level_10')) : ?>
	<div class="footer">
		<?php if ( !dynamic_sidebar('Footer') && current_user_can('level_10')) : ?>
		<div class="widgetbox rad3 placeholder-widgettext">
			<?php _de('Go to your',209); ?> <a href="<?php echo admin_url('widgets.php'); ?>"><?php _de('widgets page',210); ?></a> <?php _de('to add content here',211); ?>.
		</div> <!-- widgetbox -->
		<?php endif; ?>
        <div class="clear"></div>
	</div> <!-- FOOTER -->
	<?php endif; ?>

    <div class="underfooter">
		<div>
			&copy; <?php echo date('Y'); ?> <?php bloginfo('site_name'); ?>
		</div><div class="clear"></div>
	</div>
</div> <!-- ALL -->
<?php wp_footer(); ?>
<?php
if($_COOKIE['tos18'] != "yes" && get_option("tos18") == "1") {
?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.simplemodal.1.4.4.min.js"></script>
<script type="text/javascript">
jQuery(document).ready(function($) {
	$("#tosdisclaimer").modal({onOpen: function (dialog) {
		dialog.overlay.fadeIn('slow', function () {
			dialog.data.hide();
			dialog.container.fadeIn('slow', function () {
				dialog.data.slideDown('slow');
			});
		});
	}});
	$('.entertosdisclaimer').on('click', function(){
		$.modal.close();
		$("#tosdisclaimer").hide();
		Cookies.set('tos18', 'yes');
	});
	$('.closetosdisclaimer').on('click', function(){
		window.location = "https://www.google.com/";
	});
});
</script>
<?php
	include (get_template_directory() . '/footer-tos-18years-agreement-overlay.php');
} // if $_COOKIE != yes
?>
</body>
</html>
<!--
Lovers can see to do their amorous rites
By their own beauties; or, if love be blind,
It best agrees with night. Come, civil night,
-->