<?php
/*
Template Name: Register - Member
*/
	$err = "";
	$ok = "";
if (isset($_POST['action']) && $_POST['action'] == 'registermember') {
	include (get_template_directory() . '/register-member-personal-info-process.php');
}

get_header(); ?>

		<div class="contentwrapper">
		<div class="body">
        	<div class="bodybox registerform">
				<script type="text/javascript">
				jQuery(document).ready(function($) {
					//check if the current user is already taken
					$('#user').keyup(function(){
						var user = $('#user').val();
						var userlength = document.getElementById("user").value.length;
						if(userlength >= 4 && userlength <= 30) {
							$('.checkuser').html("");
							$.ajax({
								type: "GET",
								url: "<?php bloginfo('template_url'); ?>/ajax/check-username.php",
								data: "user=" + user,
								success: function(data){
									$('.checkuser').html(data);
								}
							});
						};
					});
				});
				</script>
            	<h3><?php _de('Member Registration',608); ?></h3>
				<?php
				if ( is_user_logged_in() ) {
					echo "<div class=\"ok rad3\">"._d('Your registration is complete.',456)."</div>";
				} else {
					include (get_template_directory() . '/register-member-personal-information-form.php');
				}
				?>
                <div class="clear"></div>
            </div> <!-- BODY BOX -->
            <div class="clear"></div>
        </div> <!-- BODY -->
		</div> <!-- contentwrapper -->

		<?php get_sidebar("left"); ?>
		<?php get_sidebar("right"); ?>

    	<div class="clear"></div>
<?php get_footer(); ?>