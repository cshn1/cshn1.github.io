<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }
?>
<?php if ($err) { echo "<div class=\"err rad3\">$err</div>"; } ?>
<?php
if ($member_edit_page == "yes") {
	$form_url = get_permalink(get_option('member_edit_personal_info_page_id'));
} else {
	$form_url = get_permalink(get_option('member_register_page_id'));
}
?>
<form action="<?php echo $form_url; ?>" method="post" class="form-styling">
	<small class="mandatory l"><?php _de('Fields marked with <i>*</i> are mandatory',323); ?></small>
    <div class="clear20"></div>

	<input type="hidden" name="action" value="registermember" />
    <input type="text" name="emails" value="" class="hide" />
    
    <?php if(!$member_edit_page) { ?>
    <div class="form-label">
	   <label for="user"><?php _de('Username',409); ?><i>*</i></label>
       <small class="checkuser"><?php _de('Between 4 and 30 characters',410); ?></small>
    </div>
    <div class="form-input">
        <input type="text" name="user" id="user" class="input longinput" value="<?php echo $user; ?>" autocomplete="off" />
    </div> <!-- user --> <div class="formseparator"></div>

    <div class="form-label">
        <label for="pass"><?php _de('Password',411); ?><i>*</i></label>
        <small><?php _de('Must be between 6 and 30 characters',412); ?></small>
    </div>
    <div class="form-input">
        <input type="password" name="pass" id="pass" class="input longinput" value="<?php echo $pass; ?>" autocomplete="off" />
    </div> <!-- password --> <div class="formseparator"></div>
    <?php } ?>

    <div class="form-label">
	   <label for="membername"><?php _de('Name',70); ?><i>*</i></label>
       <small><?php _de('will be publicly shown',414); ?></small>
    </div>
    <div class="form-input">
        <input type="text" name="membername" id="membername" class="input longinput" value="<?php echo $membername; ?>" />
    </div> <!-- name --> <div class="formseparator"></div>

    <div class="form-label">
        <label for="memberemail"><?php _de('Email',148); ?><i>*</i></label>
    </div>
    <div class="form-input">
        <input type="email" name="memberemail" id="memberemail" class="input longinput" value="<?php echo $memberemail; ?>" />
    </div> <!-- email --> <div class="formseparator"></div>

    <?php if(get_option('recaptcha_sitekey') && get_option('recaptcha_secretkey') && !is_user_logged_in() && get_option("recaptcha4")) { ?>
    <div class="form-input">
        <div class="g-recaptcha" data-sitekey="<?php echo get_option('recaptcha_sitekey'); ?>"></div>
    </div> <!-- message --> <div class="formseparator"></div>
    <?php } ?>

    <div class="center"><input type="submit" name="submit" value="<?php if($member_edit_page) { _de('Update Profile',450); } else { _de('Complete Registration',452); } ?>" class="bluebutton rad3" /></div> <!--center-->
</form>