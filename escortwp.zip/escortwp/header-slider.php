<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }

global $taxonomy_location_url, $taxonomy_profile_url;
$args = array(
	'post_type' => $taxonomy_profile_url,
	'orderby' => 'rand',
	'meta_query' => array( array('key' => 'featured', 'value' => '1', 'compare' => '=', 'type' => 'NUMERIC') ),
	'posts_per_page' => get_option("headerslideritems")
);
$q = query_posts($args);

if ( have_posts()) : ?>
<div class="all all-header-slider"<?php if(get_option("autoscrollheaderslider") == "1") echo ' data-autoscroll="yes"'; ?>>
	<div class="sliderall">
		<div class="slider owl-carousel">
			<?php
			while ( have_posts() ) : the_post();
				$category = wp_get_post_terms(get_the_ID(), $taxonomy_location_url);
				$linktitle = get_the_title();
				$imagealt = get_the_title();
				$premium = get_post_meta(get_the_ID(), "premium", true);
				$videos = get_children( array('post_parent' => get_the_ID(), 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'video', 'numberposts' => '1') );
			?>
			<div class="slide l">
	    		<a href="<?php the_permalink(); ?>" class="girlimg" title="<?php echo $linktitle; ?>">
	        		<img src="<?php echo get_first_image(get_the_ID(), 2); ?>" data-responsive-img-url="<?php echo get_first_image(get_the_ID(), '4'); ?>" alt="<?php echo $imagealt; ?>" class="mobile-ready-img" />
	        		<?php
					if ($premium == "1") { echo '<div class="premiumlabel"><span>'._d('PREMIUM',302).'</span></div>'; }

					if(count($videos) > 0) {
						echo '<span class="label-video"><img src="'.get_template_directory_uri().'/i/video-th-icon.png" alt="" /></span>';
					}
	        		?>
		        	<span class="girlinfo">
						<?php get_featured_escort_labels(get_the_ID()); ?>
						<span class="clear"></span>
						<span class="modelinfo">
			        		<span class="modelname"><?php the_title(); ?></span>
							<span class="clear"></span>
							<?php
							$location = array();
							$city = wp_get_post_terms(get_the_ID(), $taxonomy_location_url);
							if($city) {
								$location[] = $city[0]->name;

								$state = get_term($city[0]->parent, $taxonomy_location_url);
								if($state) {
									$location[] = $state->name;

									$country = get_term($state->parent, $taxonomy_location_url);
									if(!is_wp_error($country)) {
										$location[] = $country->name;
									}
								}
							}
							?>
							<span class="modelinfo-location"><?=implode(", ", $location)?></b>
			            </span>
		    	    </span> <!-- girlinfo -->
	    	    </a> <!-- GIRL IMG -->
		    </div> <!-- slide -->
			<?php endwhile; ?>
		</div> <!-- slider -->
		<div class="slider-nav">
<!-- 			<div class="slider-control-prev"><span class="icon-left-open"></span></div>
			<div class="slider-control-next"><span class="icon-right-open"></span></div> -->
		</div>
	</div> <!-- slider all -->
	<div class="header-slider-pagination slider-pagination"></div>
	<div class="clear"></div>
</div> <!-- ALL -->
<?php
endif;
wp_reset_query();
?>