<?php
	$thispostid = get_the_ID(); //this id needs to have it's own variable so it can be used in other loops
	global $current_user, $post, $taxonomy_location_url, $gender_a, $ethnicity_a, $haircolor_a, $hairlength_a, $bustsize_a, $build_a, $looks_a, $smoker_a, $availability_a, $languagelevel_a, $services_a, $currency_a, $taxonomy_profile_name, $taxonomy_agency_name, $taxonomy_profile_name_plural, $taxonomy_profile_url, $taxonomy_agency_url, $payment_options_a;
	get_currentuserinfo();
if(is_user_logged_in()) {
	$userid = $current_user->ID;
	$userstatus = get_option("escortid".$userid);
} else { $userid = "none"; $userstatus = "none"; }

	$profile_author_id = $post->post_author;

if (current_user_can('level_10')) {
	if (isset($_POST['action']) && $_POST['action'] == 'escortupgrade') {
		if ( isset($_POST['delpremium']) ) {
			update_post_meta(get_the_ID(), 'premium', "0");
			delete_post_meta(get_the_ID(), 'premium_expire');
			delete_post_meta(get_the_ID(), 'premium_renew');
			delete_post_meta(get_the_ID(), 'premium_since');
		}
		if ( isset($_POST['premium']) ) {
			update_post_meta(get_the_ID(), "premium", "1");
			update_post_meta(get_the_ID(), "premium_since", time());
			if ($_POST['premiumduration']) {
				$expiration = strtotime("+".$payment_options_a[$_POST['premiumduration']][3]." ".$payment_options_a[$_POST['premiumduration']][1]);
				if(get_post_meta(get_the_ID(), "premium_expire", true)) {
					$available_time = get_post_meta(get_the_ID(), 'premium_expire', true);
					if($available_time && $available_time > time()) { $expiration = $expiration + ($available_time - time()); }
				}
				update_post_meta(get_the_ID(), 'premium_expire', $expiration);
			} else {
				delete_post_meta(get_the_ID(), 'premium_expire');
				delete_post_meta(get_the_ID(), 'premium_renew');
			}
		}

		if ( isset($_POST['delfeatured']) ) {
			update_post_meta(get_the_ID(), "featured", "0");
			delete_post_meta(get_the_ID(), 'featured_expire');
			delete_post_meta(get_the_ID(), 'featured_renew');
		}
		if ( isset($_POST['featured']) ) {
			$featured = get_post_meta(get_the_ID(), "featured", true);
			if (!$featured || $featured == "0") { update_post_meta(get_the_ID(), "featured", "1"); }
			if ($_POST['featuredduration']) {
				$expiration = strtotime("+".$payment_options_a[$_POST['featuredduration']][3]." ".$payment_options_a[$_POST['featuredduration']][1]);
				if(get_post_meta(get_the_ID(), "featured_expire", true)) {
					$available_time = get_post_meta(get_the_ID(), 'featured_expire', true);
					if($available_time && $available_time > time()) { $expiration = $expiration + ($available_time - time()); }
				}
				update_post_meta(get_the_ID(), 'featured_expire', $expiration);
			} else {
				delete_post_meta(get_the_ID(), 'featured_expire');
				delete_post_meta(get_the_ID(), 'featured_renew');
			}
		}

		if ( isset($_POST['delexpiration']) ) {
			delete_post_meta(get_the_ID(), 'escort_expire');
			delete_post_meta(get_the_ID(), 'escort_renew');

			$price_var = (get_option("escortid".$profile_author_id) == $taxonomy_agency_url) ? "agescortregprice" : 'indescregprice';
			if(get_option($price_var) && get_option("paymentgateway")) {
				update_post_meta(get_the_ID(), 'needs_payment', "1");
				wp_update_post(array( 'ID' => get_the_ID(), 'post_status' => 'private' ));
			}
		}
		if ( isset($_POST['expirationperiod']) ) {
			if ( $_POST['profileduration'] ) {
				$expiration = strtotime("+".$payment_options_a[$_POST['profileduration']][3]." ".$payment_options_a[$_POST['profileduration']][1]);
				if(get_post_meta(get_the_ID(), "escort_expire", true)) {
					$available_time = get_post_meta(get_the_ID(), 'escort_expire', true);
					if($available_time && $available_time > time()) { $expiration = $expiration + ($available_time - time()); }
				}
				update_post_meta(get_the_ID(), 'escort_expire', $expiration);
			} else {
				delete_post_meta(get_the_ID(), 'escort_expire');
				delete_post_meta(get_the_ID(), 'escort_renew');
			}
		}

		if ( isset($_POST['verified']) ) {
			$verified = get_post_meta(get_the_ID(), "verified", true);
			if ($verified == "1") {
				$verified = "0";
			} else {
				$verified = "1";
			}
			update_post_meta(get_the_ID(), "verified", $verified);
		}
		wp_redirect(get_permalink(get_the_ID())); exit();
	} // escort upgrade

	if (isset($_POST['action']) && $_POST['action'] == 'adminnote') {
		$adminnote = wp_strip_all_tags($_POST['adminnote']);
		update_post_meta(get_the_ID(), "adminnote", $adminnote);
		wp_redirect(get_permalink(get_the_ID())); exit();
	} // adminnote

	if (isset($_POST['action']) && $_POST['action'] == 'activateprivateprofile') {
		$privprof = array( 'ID' => get_the_ID(), 'post_status' => 'publish' );
		delete_post_meta(get_the_ID(), "notactive");
		wp_update_post($privprof);
		wp_redirect(get_permalink(get_the_ID())); exit;
	} // activate private escort

	if (isset($_POST['action']) && $_POST['action'] == 'activateunpaidprofile') {
		if ($_POST['profileduration']) {
			$expiration = strtotime("+".$payment_options_a[$_POST['profileduration']][3]." ".$payment_options_a[$_POST['profileduration']][1]);
			if(get_post_meta(get_the_ID(), "escort_expire", true)) {
				$available_time = get_post_meta(get_the_ID(), 'escort_expire', true);
				if($available_time && $available_time > time()) { $expiration = $expiration + ($available_time - time()); }
			}
			update_post_meta(get_the_ID(), 'escort_expire', $expiration);
		}

		$unpaidprof = array( 'ID' => get_the_ID(), 'post_status' => 'publish' );
		delete_post_meta(get_the_ID(), "needs_payment");
		wp_update_post($unpaidprof);
		wp_redirect(get_permalink(get_the_ID())); exit;
	} // activate unpaid profile
} // if admin

if ($userstatus == "member") {
	if (isset($_POST['action']) && $_POST['action'] == 'addreview') {
		$rateescort = (int)$_POST['rateescort'];
		if ($rateescort < 1 || $rateescort > 6) {
			$err .= _d('The %s rating is wrong. Please select again',721,$taxonomy_profile_name)."<br />"; unset($rateescort);
		}

		$reviewtext = substr(stripslashes(wp_kses($_POST['reviewtext'], array())), 0, 5000);
		if (!$reviewtext) {
			$err .= _d('You didn\'t write a review',677)."<br />";
		}

		if (!$err) {
			//add review to database
			if (get_option("manactivesc") == "1") {
				$reviewstatus = "draft";
			} else {
				$reviewstatus = "publish";
			}
			$reviews_cat_id = term_exists( 'Reviews', "category" );
			if (!$reviews_cat_id) {
				$arg = array('description' => 'Reviews');
				wp_insert_term('Reviews', "category", $arg);
				$reviews_cat_id = term_exists( 'Reviews', "category" );
			}
			$reviews_cat_id = $reviews_cat_id['term_id'];
			$add_review = array(
				'post_title' => _d('review for',722)." ".get_the_title(),
				'post_content' => $reviewtext,
				'post_status' => $reviewstatus,
				'post_author' => $userid,
				'post_category' => array($reviews_cat_id),
				'post_type' => 'review',
				'ping_status' => 'closed'
			);
			$add_review_id = wp_insert_post( $add_review );
			update_post_meta($add_review_id, "rateescort", $rateescort);
			update_post_meta($add_review_id, "escortid", get_the_ID());
			update_post_meta($add_review_id, "reviewfor", profile);

			$reviewadminurl = admin_url('post.php').'?post='.$add_review_id.'&action=edit';
			if (get_option("manactivesc") == "1") {
				$new_review_email_title = _d('A new review is waiting for approval on',680)." ".get_option("email_sitename");
			} else {
				$new_review_email_title = _d('Someone wrote a %s review on',723,$taxonomy_profile_name).' '.get_option("email_sitename");
			}
			$body = _d('Hello',17).',<br />
'._d('Someone wrote a %s review on',723,$taxonomy_profile_name).' '.get_option("email_sitename").':<br /><br />
'._d('Read/Edit the review here',679).':<br />
<a href="'.$reviewadminurl.'">'.$reviewadminurl.'</a><br />'._d('(to activate the review simply click te button "Publish")',724);
			if(get_option("ifemail6") == "1" || get_option("manactivag") == "1") {
				dolce_email(null, null, get_bloginfo("admin_email"), $new_review_email_title, $body);
			}

			if (get_option("permalink_structure")) {
				wp_redirect(get_permalink(get_the_id())."?postreview=ok"); exit();
			} else {
				wp_redirect(get_permalink(get_the_id())."&postreview=ok"); exit();
			}
			
		}
	} // add review
} // if user status member

//delete an escort account
if (isset($_POST['action']) && $_POST['action'] == 'deleteescort' && ($profile_author_id == $userid && $userstatus == $taxonomy_agency_url || current_user_can('level_10'))) {
	if (!get_post_meta(get_the_ID(), "independent", true)) {
		$agency_id = get_option("agencypostid".$profile_author_id);
	}

	delete_profile(get_the_ID()); //delete escort and everything related to the profile

	if ($agency_id) {
		wp_redirect(get_permalink($agency_id)); exit();
	} else {
		wp_redirect(get_bloginfo("url")); exit();
	}
} // if admin


// set profile to private
if (isset($_POST['action']) && $_POST['action'] == 'settoprivate') {
	$new_post_status = get_post_status(get_the_ID()) == "publish" ? "private" : "publish";

	if(current_user_can('level_10')) {
		if(get_post_status(get_the_ID()) == "publish") {
			update_post_meta(get_the_ID(), 'notactive', '1');
		} else {
			delete_post_meta(get_the_ID(), "notactive");
		}
		wp_update_post(array('ID' => get_the_ID(), 'post_status' => $new_post_status));
	}

	if($profile_author_id == $userid && !get_post_meta(get_the_ID(), 'notactive', true) && !get_post_meta(get_the_ID(), 'needs_payment', true)) {
		wp_update_post(array('ID' => get_the_ID(), 'post_status' => $new_post_status));
	}

	wp_redirect(get_permalink(get_the_ID())); die();
}



//if the agency wants to edit the profile information process the data below
if (isset($_POST['action']) && $_POST['action'] == 'register') {
	if ($profile_author_id == $userid && $userstatus == $taxonomy_agency_url || current_user_can('level_10')) {
		$agencyid = $userid;
		$single_page = "yes";
		$escort_post_id = get_the_ID();
		include (get_template_directory() . '/register-independent-personal-info-process.php');
	} // if the escort was added by this user and if the user is an agency
} else {
	$agencyid = $userid;
	$escort_post_id = get_the_ID();
	$single_page = "yes";
	$escort = get_post($escort_post_id);

	$aboutyou = nl2br(do_shortcode($escort->post_content));
	$yourname = $escort->post_title;

	$phone = get_post_meta($escort_post_id, "phone", true);
	$escortemail = get_post_meta($escort_post_id, "escortemail", true);
	$website = get_post_meta($escort_post_id, "website", true);

	if(get_option('locationdropdown') == "1") {
		$country = get_post_meta($escort_post_id, "country", true);
		if(showfield('state')) {
			$state = get_post_meta($escort_post_id, "state", true);
		}
		$city_id = get_post_meta($escort_post_id, "city", true);
		$city = $city_id;
	} else {
		$country = get_post_meta($escort_post_id, "country", true);
		if(showfield('state')) {
			$state = get_term(get_post_meta($escort_post_id, "state", true), $taxonomy_location_url);
			$state = $state->name;
		}
		$city_id = get_post_meta($escort_post_id, "city", true);
		$city = get_term($city_id, $taxonomy_location_url);
		$city = $city->name;
	}


	$gender = get_post_meta($escort_post_id, "gender", true);
	$birthday = get_post_meta($escort_post_id, "birthday", true);
	$age = floor((time() - strtotime($birthday))/31556926);
	$birthday_expaned = explode("-", $birthday);
	$dateyear = $birthday_expaned[0];
	$datemonth = $birthday_expaned[1];
	$dateday = $birthday_expaned[2];
	
	$ethnicity = get_post_meta($escort_post_id, "ethnicity", true);
	$haircolor = get_post_meta($escort_post_id, "haircolor", true);
	$hairlength = get_post_meta($escort_post_id, "hairlength", true);
	$bustsize = get_post_meta($escort_post_id, "bustsize", true);
	$height = get_post_meta($escort_post_id, "height", true);
	$weight = get_post_meta($escort_post_id, "weight", true);
	$build = get_post_meta($escort_post_id, "build", true);
	$looks = get_post_meta($escort_post_id, "looks", true);
	$smoker = get_post_meta($escort_post_id, "smoker", true);
	$availability = get_post_meta($escort_post_id, "availability", true);
	$language1 = get_post_meta($escort_post_id, "language1", true);
	$language1level = get_post_meta($escort_post_id, "language1level", true);
	$language2 = get_post_meta($escort_post_id, "language2", true);
	$language2level = get_post_meta($escort_post_id, "language2level", true);
	$language3 = get_post_meta($escort_post_id, "language3", true);
	$language3level = get_post_meta($escort_post_id, "language3level", true);
	$currency = get_post_meta($escort_post_id, "currency", true);

	$rate30min_incall = get_post_meta($escort_post_id, "rate30min_incall", true);
	$rate1h_incall = get_post_meta($escort_post_id, "rate1h_incall", true);
	$rate2h_incall = get_post_meta($escort_post_id, "rate2h_incall", true);
	$rate3h_incall = get_post_meta($escort_post_id, "rate3h_incall", true);
	$rate6h_incall = get_post_meta($escort_post_id, "rate6h_incall", true);
	$rate12h_incall = get_post_meta($escort_post_id, "rate12h_incall", true);
	$rate24h_incall = get_post_meta($escort_post_id, "rate24h_incall", true);

	$rate30min_outcall = get_post_meta($escort_post_id, "rate30min_outcall", true);
	$rate1h_outcall = get_post_meta($escort_post_id, "rate1h_outcall", true);
	$rate2h_outcall = get_post_meta($escort_post_id, "rate2h_outcall", true);
	$rate3h_outcall = get_post_meta($escort_post_id, "rate3h_outcall", true);
	$rate6h_outcall = get_post_meta($escort_post_id, "rate6h_outcall", true);
	$rate12h_outcall = get_post_meta($escort_post_id, "rate12h_outcall", true);
	$rate24h_outcall = get_post_meta($escort_post_id, "rate24h_outcall", true);

	$services = get_post_meta($escort_post_id, "services", true);
	$extraservices = get_post_meta($escort_post_id, "extraservices", true);
	$adminnote = get_post_meta($escort_post_id, "adminnote", true);
	$education = get_post_meta(get_the_ID(),'education', true);
	$sports = get_post_meta(get_the_ID(),'sports', true);
	$hobbies = get_post_meta(get_the_ID(),'hobbies', true);
	$zodiacsign = get_post_meta(get_the_ID(),'zodiacsign', true);
	$sexualorientation = get_post_meta(get_the_ID(),'sexualorientation', true);
	$occupation = get_post_meta(get_the_ID(),'occupation', true);
}

if ($profile_author_id == $userid && $userstatus == $taxonomy_agency_url || current_user_can('level_10')) {
	//if the agency wants to add a tour to the escort then process the data below
	if (isset($_POST['action']) && ($_POST['action'] == 'addtour' || $_POST['action'] == 'edittour')) {
		$is_escort_page = "yes";
		$escort_post_id_for_tours = get_the_ID();
		include (get_template_directory() . '/register-independent-manage-my-tours-process-data.php');
	}
} // if the escort was added by this user and if the user is an agency


if (isset($_POST['action']) && $_POST['action'] == "contactform") {
	if ($_POST['emails']) { $err .= "."; }

	if (is_user_logged_in()) {
		$contactformname = $current_user->display_name;
		$contactformemail = $current_user->user_email;
	} else {
		$contactformname = wp_strip_all_tags($_POST['contactformname']);
		if (!$contactformname) { $err .= _d('Your name is missing',363)."<br />"; }

		$contactformemail = $_POST['contactformemail'];
		if ($contactformemail) {
			if ( !is_email($contactformemail) ) { $err .= _d('Your email address seems to be wrong',561)."<br />"; }
		} else {
			$err .= _d('Your email is missing',364)."<br />";
		}
	}

	$contactformmess = wp_strip_all_tags($_POST['contactformmess']);
	if (!$contactformmess) { $err .= _d('You need to write a message',365)."<br />"; }

	if (!$err) {
		$body = _d('Hello',17).' '.get_the_author_meta('display_name', $profile_author_id).'<br /><br />
'._d('Someone sent you a message from',366).' '.get_option("email_sitename").':<br />
<a href="'.get_permalink(get_the_ID()).'">'.get_permalink(get_the_ID()).'</a><br /><br />
'._d('Sender information',367).':<br />
'._d('name',70).': <b>'.$contactformname.'</b><br />
'._d('email',48).': <b>'.$contactformemail.'</b><br />
'._d('message',369).':<br />'.$contactformmess.'<br /><br />'._d('You can send a message back to this person by replying to this email.',370);
		dolce_email($contactformname, $contactformemail, get_the_author_meta('user_email', $profile_author_id), _d('Message from',371)." ".get_option("email_sitename"), $body);
		unset($contactformname, $contactformemail, $contactformmess, $body);
		$ok = _d('Message sent',372);
	}
}

get_header(); ?>

<div class="contentwrapper">
	<div class="body">
		<div class="bodybox profile-page">
			<?php if ( $ok && ($_POST['action'] == 'addtour' || $_POST['action'] == 'edittour')) { echo "<div class=\"ok rad3\">$ok</div>"; } ?>

			<script type="text/javascript">
			jQuery(document).ready(function($) {
				//add or remove from favorites
				$('.favbutton').on('click', function(){
					var escortid = $(this).attr('id');
					$('.favbutton').toggle();
					$.ajax({
						type: "GET",
						url: "<?php bloginfo('template_url'); ?>/ajax/add-remove-favorites.php",
						data: "id=" + escortid
					});
				});

				$('.addreview-button').on('click', function(){
					$('.addreviewform').slideDown("slow");
					$('.addreview').slideUp("slow");
					$('html,body').animate({ scrollTop: $('.addreviewform').offset().top }, { duration: 'slow', easing: 'swing'});
				});
			    if(window.location.hash == "#addreview") {
					// $('.addreviewform, .addreview').slideToggle("slow");
					$('html,body').animate({ scrollTop: $('#addreviewsection').offset().top }, { duration: 'slow', easing: 'swing'});
				}
				$('.addreviewform .closebtn').on('click', function(){
					$('.addreviewform, .addreview').slideToggle("slow");
				});

				count_review_text('#reviewtext');
				$("#reviewtext").keyup(function() {
					count_review_text($(this));
				});
				function count_review_text(t) {
					if (!$(t).length) {
						return false;
					}
					var charlimit = 1000;
					var box = $(t).val();
					var main = box.length * 100;
					var value = (main / charlimit);
					var count = charlimit - box.length;
					var boxremove = box.substring(0, charlimit);
					var ourtextarea = $(t);

					$('.charcount').show('slow');
					if(box.length <= charlimit) {
						$('#count').html(count);
						$("#reviewtext")
						$('#bar').animate( {
							"width": value+'%',
						}, 1);
					} else {
						$('#reviewtext').val(boxremove);
			            ourtextarea.scrollTop(
			                ourtextarea[0].scrollHeight - ourtextarea.height()
			            );
					}
					return false;
				}

				$('.sendemail').on('click', function(){
					$('.escortcontact').slideToggle("slow");
					$(this).slideToggle("slow");
				});
			    if(window.location.hash == "#contactform") {
					$('html,body').animate({ scrollTop: $('.escortcontact').offset().top }, { duration: 'slow', easing: 'swing'});
					$('.escortcontact').slideToggle("slow");
					$('.sendemail').slideToggle("slow");
				}
				$('.escortcontact .closebtn').on('click', function(){
					$('.escortcontact').slideToggle("slow");
					$('.sendemail').slideToggle("slow");
				});


				<?php
				if($availability) {
					if(!in_array("1", $availability)) {
						echo '$(\'.girlinfo .hide-incall\').hide();';
					}
					if(!in_array("2", $availability)) {
						echo '$(\'.girlinfo .hide-outcall\').hide();';
					}
				}
				?>
			});
			</script>
			<?php
			//check if the user has any photos uploaded
			//create an array with all the photos to use later
			$photos = get_children( array('post_parent' => get_the_ID(), 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => 'ASC', 'orderby' => 'menu_order ID') );
			$photos_left = get_option('maximgupload') - count($photos); $photos_left = (int)$photos_left;

			$videos = get_children( array('post_parent' => get_the_ID(), 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'video', 'order' => 'ASC', 'orderby' => 'menu_order ID') );
			$videos_left = get_option('maxvideoupload') - count($videos);

			if ($profile_author_id == $userid || current_user_can('level_10')) {
				include (get_template_directory() . '/register-agency-manage-escorts-option-buttons.php');
			}
			?>
		    <div class="girlsingle<?php if($err && in_array($_POST['action'], array('adminnote', 'addtour', 'edittour', 'register'))) { echo " hide"; } ?>" itemscope itemtype ="http://schema.org/Person">
		    <div class="profile-header">
		    	<div class="profile-header-name l">
			    	<h3 class="profile-title" title="<?php the_title_attribute(); ?>" itemprop="name"><?php the_title(); ?></h3>
			        <div class="girlsinglelabels">
						<?php
							$premium = get_post_meta(get_the_ID(), "premium", true);
							if ($premium == "1") { echo '<span class="orangebutton rad25">'._d('PREMIUM',302).'</span>'; }

							$featured = get_post_meta(get_the_ID(), "featured", true);
							if ($featured == "1") { echo '<span class="bluedegrade rad25">'.strtoupper(_d('Featured',633)).'</span>'; }

							$verified = get_post_meta(get_the_ID(), "verified", true);
							if ($verified == "1") { echo '<span class="greendegrade rad25">'._d('VERIFIED',284).'</span>'; }

							$daysago = date("Y-m-d H:i:s", strtotime("-".get_option('newlabelperiod')." days"));
							if (get_the_time('Y-m-d H:i:s') > $daysago) {
								echo '<span class="pinkbutton rad25">'._d('NEW',285).'</span>';
							}

							if(get_post_status(get_the_ID()) == "private") {
								echo '<span class="redbutton rad25">'.strtoupper(_d('Private',1292)).'</span>';
							}
						?>
					</div> <!-- girlsinglelabels -->
				</div>
				<div class="profile-header-name-info rad5 r">
					<?php
		            if($height) { echo '<div class="section-box"><span class="valuecolumn">'.$height.'</span><b>cm</b></div>'; }
		            if($weight) { echo '<div class="section-box"><span class="valuecolumn">'.$weight.'</span><b>kg</b></div>'; }
		            ?>
					<div class="section-box"><span class="valuecolumn"><?=$age?></span><b><?=_d('years',1290)?></b></div>
				</div>
				<?php
				if(get_option("viphide2") && get_option("paymentgateway") && !is_user_logged_in()) {
				} else {
					$unlocked_escorts = get_user_meta($userid, 'unlocked_escorts', true);
					if(!$unlocked_escorts) $unlocked_escorts = array();
					if(get_option("viphide2") && get_option("paymentgateway") && !get_user_meta($userid, "vip", true) && !in_array(get_the_ID(), $unlocked_escorts) && !current_user_can('level_10') && $profile_author_id != $userid) {
					} else {
						if($phone) { ?>
							<div class="phone-box r">
								<div class="label"><?=_d('call me',1291)?></div>
								<a class="" href="tel:<?=$phone?>" itemprop="telephone"><span class="icon icon-phone"></span><?=$phone?></a>
							</div>
						<?php }
					} // if VIP or admin
				} // if contact section hidden and user not logged in
				?>
				<div class="clear"></div>
			</div> <!-- profile-header -->

			<?php
			if ($adminnote) {
				echo '<div class="clear"></div>';
				echo '<div class="err rad3">'.$adminnote.'</div>';
			}
			?>
			<?php if ($profile_author_id == $userid || current_user_can('level_10')) { ?>
				<div class="clear10"></div>
				<div class="profile-page-no-media-wrapper profile-page-no-media-wrapper-photos <?=(get_option('allowvideoupload') == "1") ? " col50 l" : " col100"?>">
					<div class="profile-page-no-media profile-page-no-photos profile-page-no-photos-click rad3 col100 text-center" id="profile-page-no-photos">
						<div class="icon icon-picture"></div>
						<div class="for-browsers" data-mobile-text="<?php _de("Tap here to upload your images",1094); ?>">
							<p><?php _de("Drag your images here to upload them",1091); ?> <?php _de("or <u>Select from a folder</u>",1092); ?></p>
						</div>
						<p class="max-photos"><?php _de('You can upload a maximum of %s images',1093, '<b>'.$photos_left.'</b>'); ?></p>
						<div class="clear"></div>
					</div>
					<div class="profile_photos_button_container hide"><input id="profile_photos_upload" name="file_upload" type="file" /></div>
				</div> <!-- profile-page-no-media-wrapper -->

				<?php if(get_option('allowvideoupload') == "1") { ?>
				<div class="profile-page-no-media-wrapper profile-page-no-media-wrapper-videos col50 r">
					<div class="profile-page-no-media profile-page-no-videos profile-page-no-videos-click rad3 col100 text-center" id="profile-page-no-videos">
						<div class="icon icon-film"></div>
						<div class="for-browsers" data-mobile-text="<?php _de("Tap here to upload your videos",1259); ?>">
							<p><?php _de("Drag your videos here to upload them",1258); ?> <?php _de("or <u>Select from a folder</u>",1092); ?></p>
						</div>
						<p class="max-videos"><?php _de('You can upload a maximum of %s videos',1260, '<b>'.$videos_left.'</b>'); ?></p>
						<div class="clear"></div>
					</div>
					<div class="profile_videos_button_container hide"><input id="profile_videos_upload" name="file_upload" type="file" /></div>
				</div> <!-- profile-page-no-media-wrapper -->
				<?php } ?>
				<div class="clear20"></div>
			<?php } ?>

			<?php
			if($photos || $videos) { //we only show the code for the main image and the thumbs if the user has at least one image
				if ($profile_author_id == $userid || current_user_can('level_10')) {
					echo '
					<div class="image-buttons-legend r">
						<div class="first l">
							<span class="button-delete icon-cancel"></span> '._d('Delete image',496).'
						</div>
						<div class="last l">
							<span class="button-main-image icon-ok"></span> '._d('Mark as main image',589).'
						</div>
					</div>';
				} // if user is author
			?>
			<div class="clear10"></div>
			<?php /* ?>
        	<div class="bigimage l hide">
				<?php
					$main_image_id = get_post_meta(get_the_ID(), "main_image_id", true);
					if($main_image_id < 1 || !get_post($main_image_id)) {
						$firstphoto = reset($photos);
						if ($firstphoto) {
							$main_image_id = $firstphoto->ID;
							update_post_meta(get_the_ID(), "main_image_id", $main_image_id);
						}
					}

					$main_image_url = wp_get_attachment_image_src((int)$main_image_id, 'main-image-thumb');
					if($main_image_url[3] != "1") {
						require_once( ABSPATH . 'wp-admin/includes/image.php' );
						$attach_data = wp_generate_attachment_metadata($main_image_id, get_attached_file($main_image_id));
						wp_update_attachment_metadata($main_image_id, $attach_data);
						$main_image_url = wp_get_attachment_image_src($main_image_id, 'main-image-thumb');
					}
					if(!$main_image_url[0]) {
						$main_image_url[0] = get_template_directory_uri().'/i/no-image-agency.png';
					}
					echo '<img src="'.$main_image_url[0].'" class="rad3 l" alt="'.get_the_title().'" />'."\n";
				?>
            </div> <!-- BIG IMAGE -->
            <?php */ ?>
            <div class="thumbs" itemscope itemtype="http://schema.org/ImageGallery">
				<?php
				$nrofphotos = count($photos) - 1; //nr of photos left if we exclude the main big image
				$nrofvideos = count($videos);
				if(count($photos) > 0 || $nrofvideos > 0) {
					if($nrofvideos > 0) {
						$and_videos = ' '._d('and %d more videos',1268,'<span class="nr rad5 pinkdegrade">'.$nrofvideos.'</span>');
					}
					if(get_option("viphide1") && get_option("paymentgateway") && !is_user_logged_in()) {
						echo '<div class="lockedsection rad5">'.
							'<div class="icon icon-lock l"></div>'.
							_d('This %s has %s more photos',1097, array($taxonomy_profile_name, '<span class="nr rad5 pinkdegrade">'.$nrofphotos.'</span>')).$and_videos.'.<br />'.
							_d('You need to',617).' <a href="'.get_permalink(get_option('main_reg_page_id')).'">'._d('register',618).'</a> '._d('or',619).' <a href="'.wp_login_url(get_permalink()).'">'._d('login',620).'</a> '._d('to be able to view the other photos',873).'.'.
							'<div class="clear"></div>'.
							'</div>';
					} else {
						$unlocked_escorts = get_user_meta($userid, 'unlocked_escorts', true);
						if(!$unlocked_escorts) $unlocked_escorts = array();
						if(get_option("viphide1") && get_option("paymentgateway") && !get_user_meta($userid, "vip", true) && !in_array(get_the_ID(), $unlocked_escorts) && !current_user_can('level_10') && $profile_author_id != $userid) {
							echo '<div class="clear5"></div>'.
								'<div class="lockedsection rad5">'.
								'<div class="icon icon-lock l"></div>';
							_de('This %s has %s more photos',1097, array($taxonomy_profile_name, '<span class="nr rad5 pinkdegrade">'.$nrofphotos.'</span>')).$and_videos.'.<br />';
							if(get_option("vipunlock") == "yes") {
								echo _d('To see all the photos you will need to unlock this profile by paying a one time fee of',877)." ";
								echo '<strong>'.format_price('4')."</strong>.";
								echo '<div class="clear10"></div>';
								echo '<div class="center">'.generate_payment_buttons('4',$userid."-".get_the_ID())."</div> <!--center-->";
							} else {
								echo _d('You need to be a VIP member to see the rest of the photos',878).". ";
								echo _d('VIP status costs',879).' <strong>'.format_price('5')."</strong>.<br />";
								if(get_option("vipduration")) {
									echo _d('Your VIP status will be active for',884).' <strong>'.$payment_options_a[get_option("vipduration")][0].'</strong> ';
									if(get_option("vipsubscription") == "yes") {
										echo _d('and you\'ll be billed again after that period expires',885).".";
									}
								}
								echo '<div class="clear10"></div>';
								echo '<div class="center">'.generate_payment_buttons('5',$userid)."</div> <!--center-->";
							}
							echo '</div>';
						} else {
							// get the videos uploaded
							foreach ($videos as $video) {
								if ($profile_author_id == $userid || current_user_can('level_10')) {
									$imagebuttons = '<span class="edit-buttons"><span class="icon button-delete icon-cancel rad3"></span></span>';
								}

								echo '<div class="profile-video-thumb-wrapper"><div class="profile-img-thumb profile-video-thumb rad3"  id="'.$video->ID.'" style="background: url('.$video->guid.'.jpg) center no-repeat; background-size: cover;">';
								echo 	$imagebuttons;

								if(get_post_meta($video->ID, 'processing', true) && !is_video_processing_running(get_post_meta($video->ID, 'processing', true))) {
									delete_post_meta($video->ID, 'processing');
									unlink(get_post_meta($video->ID, "original_file", true));
									delete_post_meta($video->ID, 'original_file');

								}
								$file_path = get_attached_file($video->ID);
								$file_path_thumb = $file_path.".jpg";
								if(!file_exists($file_path_thumb)) {
									$output = shell_exec("ffmpeg -i $file_path");
									$videoresizeheight = get_option("videoresizeheight") ? get_option("videoresizeheight") : '400';
									shell_exec("ffmpeg -y -i $file_path -f mjpeg -vframes 1 -ss 00:00:03.435 -vf scale=".$videoresizeheight.":-1 $file_path_thumb");
								}

								if(get_post_meta($video->ID, 'processing', true)) {
									if ($profile_author_id == $userid || current_user_can('level_10')) {
										echo '<span class="video-processing rad3">'._d('this video is still processing',1269).'</span>';
										echo '<img data-original-url="'.get_template_directory_uri().'/i/video-placeholder.svg" class="mobile-ready-img rad3" alt="'.get_the_title().'" data-responsive-img-url="'.get_template_directory_uri().'/i/video-placeholder-mobile.svg" />';
									}
								} else {
									echo '<div id="'.preg_replace("/([^a-zA-Z0-9])/", "", $video->post_title).'" class="video-player-lightbox text-center hide" itemprop="video" itemscope itemtype="http://schema.org/VideoObject">';
									echo 	'<meta itemprop="thumbnailUrl" content="'.$video->guid.'.jpg" />';
									echo 	'<meta itemprop="contentURL" content="'.$video->guid.'" />';
									echo 	'<video height="100%" width="100%" controls>';
									echo 		'<source src="'.$video->guid.'" type="video/mp4">';
									echo 		_d("Your browser does not support the video tag.",1270);
									echo 	'</video> ';
									echo '</div>';

									echo '<a href="#'.preg_replace("/([^a-zA-Z0-9])/", "", $video->post_title).'" rel="profile-video">';
									echo 	'<img src="'.$video->guid.'.jpg" class="hide" />';
									echo 	'<img src="'.get_template_directory_uri().'/i/video-placeholder.svg" class="video-image-play" />';
									echo '</a>';
								}

								echo '<div class="clear"></div></div></div>'."\n";
							}
							if(count($videos) > 0) {
								echo '<div class="clear10"></div>';
							}
							// get the images uploaded
							foreach ($photos as $photo) {
								$photo_th_url = wp_get_attachment_image_src($photo->ID, 'profile-thumb');
								if($photo_th_url[3] != "1") {
									require_once( ABSPATH . 'wp-admin/includes/image.php' );
									$attach_data = wp_generate_attachment_metadata($photo->ID, get_attached_file($photo->ID));
									wp_update_attachment_metadata($photo->ID, $attach_data);
									$photo_th_url = wp_get_attachment_image_src($photo->ID, 'profile-thumb');
								}

								$photo_th_mobile_url = wp_get_attachment_image_src($photo->ID, 'profile-thumb-mobile');
								if($photo_th_mobile_url[3] != "1") {
									require_once( ABSPATH . 'wp-admin/includes/image.php' );
									$attach_data = wp_generate_attachment_metadata($photo->ID, get_attached_file($photo->ID));
									wp_update_attachment_metadata($photo->ID, $attach_data);
									$photo_th_mobile_url = wp_get_attachment_image_src($photo->ID, 'profile-thumb-mobile');
								}

								if ($profile_author_id == $userid || current_user_can('level_10')) {
									$imagebuttons = '<span class="edit-buttons"><span class="icon button-delete icon-cancel rad3"></span><span class="icon button-main-image icon-ok rad3"></span></span>';
								}
								echo '<div class="profile-img-thumb-wrapper"><div class="profile-img-thumb" id="'.$photo->ID.'" itemprop="image" itemscope itemtype="http://schema.org/ImageObject">';
								echo 	$imagebuttons;
								echo 	'<a href="'.$photo->guid.'" rel="profile-photo" itemprop="contentURL">';
								echo 		'<img data-original-url="'.$photo_th_url[0].'" class="mobile-ready-img rad3" alt="'.get_the_title().'" data-responsive-img-url="'.$photo_th_mobile_url[0].'" itemprop="thumbnailUrl" />';
								echo 	'</a>';
								echo '</div></div>'."\n";
							}
						} // if photo section is locked and user is not VIP
					} // is photo section locked and user is not logged in
				} // if escort has at least one photo
				?>
			</div> <!-- THUMBS -->

			<div class="clear20"></div>
			<?php } // if at least one photo uploaded ?>

			<?php
				$location = array();
				$city = wp_get_post_terms(get_the_ID(), $taxonomy_location_url);
				if($city) {
					$location[] = '<a href="'.get_term_link($city[0]).'" title="'.$city[0]->name.'">'.$city[0]->name.'</a>';

					$state = get_term($city[0]->parent, $taxonomy_location_url);
					if($state) {
						$location[] = '<a href="'.get_term_link($state).'" title="'.$state->name.'">'.$state->name.'</a>';

						$country = get_term($state->parent, $taxonomy_location_url);
						if(!is_wp_error($country)) {
							$location[] = '<a href="'.get_term_link($country).'" title="'.$country->name.'">'.$country->name.'</a>';
						}
					}
				}
			?>
			<div class="clear"></div>
            <div class="aboutme">
				<h4><?php _de('About me',725); ?>:</h4>
				<b><?=$age?> <?=_d('year old',1209)?> <span itemprop="gender"><?=$gender_a[$gender]?></span> <?=_d('from',1210)?> <?=implode(", ", $location)?></b>
                <div class="clear5"></div>
				<?php echo $aboutyou; ?>
			</div> <!-- ABOUT ME -->
            <div class="clear10"></div>

            <div class="girlinfo l">
	            <div class="girlinfo-section">
	            	<?php if(!get_option("hide1")) { ?>
		                <div class="center profilestarrating-wrapper">
		                	<div class="starrating"><div class="starrating_stars star<?php echo get_escort_rating(get_the_ID(), false); ?>"></div></div>
			                <div class="clear5"></div>
			                <div class="label"><?php _de('%s rating',727,ucfirst($taxonomy_profile_name)); ?></div>
			                <div class="clear"></div>
		                	<i><?=get_escort_rating(get_the_ID(), true)." ".strtolower(_d('reviews',728)); ?></i>
			                <div class="clear"></div>
		                </div>
		                <div class="clear10"></div>
		                <div class="clear10"></div>
	                <?php } // hide ratings ?>
	                <?php
					$favorites = get_user_meta( $userid, "favorites", true);
					if ($favorites) {
						$favorites = array_unique(explode(",", $favorites));
					} else {
						$favorites = array();
					}

					if ($userstatus == "member" || current_user_can('level_10')) {
						if (in_array(get_the_ID(), $favorites)) {
							$addclass = '';
							$remclass = ' style="display: none;"';
						} else {
							$addclass = ' style="display: none;"';
							$remclass = '';
						}
					?>
					<div class="text-center">
						<?php if(!get_option("hide1")) { ?>
			                <div class="addreview-button rad25 bluebutton"><span class="icon-plus-circled"></span><?php _de('Add Review',685); ?></div>
		                <?php } // hide ratings ?>
						<div class="removefromfavorites rad25 bluebutton favbutton" id="rem<?php the_ID(); ?>"<?php echo $addclass; ?>><span class="icon-heart"></span><?php _de('Remove Favorite',729); ?></div>
						<div class="addtofavorites rad25 bluebutton favbutton" id="add<?php the_ID(); ?>"<?php echo $remclass; ?>><span class="icon-heart"></span><?php _de('Add to Favorites',730); ?></div>
					</div>
	                <?php } ?>
	                <div class="clear"></div>
		        	<?php
	                if($availability) {
	                	foreach($availability as $a_id) {
							$availability_show[] = $availability_a[$a_id];
						}
	                	echo '<div class="section-box"><b>'._d('Availability',394).'</b><span class="valuecolumn">'.implode(", ", $availability_show).'</span></div>';
					}
		        	if($ethnicity) { echo '<div class="section-box"><b>'._d('Ethnicity',392).'</b><span class="valuecolumn">'.$ethnicity_a[$ethnicity].'</span></div>'; }
	    	        if($haircolor) { echo '<div class="section-box"><b>'._d('Hair color',403).'</b><span class="valuecolumn">'.$haircolor_a[$haircolor].'</span></div>'; }
	                if($hairlength) { echo '<div class="section-box"><b>'._d('Hair length',404).'</b><span class="valuecolumn">'.$hairlength_a[$hairlength].'</span></div>'; }
	                if($bustsize) { echo '<div class="section-box"><b>'._d('Bust size',405).'</b><span class="valuecolumn">'.$bustsize_a[$bustsize].'</span></div>'; }
		            if($height) { echo '<div class="section-box"><b itemprop="height">'._d('Height',406).'</b><span class="valuecolumn">'.$height.'cm</span></div>'; }
		            if($weight) { echo '<div class="section-box"><b itemprop="weight">'._d('Weight',413).'</b><span class="valuecolumn">'.$weight.'kg</span></div>'; }
	    	        if($build) { echo '<div class="section-box"><b>'._d('Build',407).'</b><span class="valuecolumn">'.$build_a[$build].'</span></div>'; }
	                if($looks) { echo '<div class="section-box"><b>'._d('Looks',408).'</b><span class="valuecolumn">'.$looks_a[$looks].'</span></div>'; }
	                if($smoker) { echo '<div class="section-box"><b>'._d('Smoker',395).'</b><span class="valuecolumn">'.$smoker_a[$smoker].'</span></div>'; }
					if ($education) { echo '<div class="section-box"><b>'._d('Education',434).'</b><span class="valuecolumn">'.$education.'</span></div>'; }
					if ($sports) { echo '<div class="section-box"><b>'._d('Sports',435).'</b><span class="valuecolumn">'.$sports.'</span></div>'; }
					if ($hobbies) { echo '<div class="section-box"><b>'._d('Hobbies',436).'</b><span class="valuecolumn">'.$hobbies.'</span></div>'; }
					if ($zodiacsign) { echo '<div class="section-box"><b>'._d('Zodiac sign',437).'</b><span class="valuecolumn">'.$zodiacsign.'</span></div>'; }
					if ($sexualorientation) { echo '<div class="section-box"><b>'._d('Sexual orientation',438).'</b><span class="valuecolumn">'.$sexualorientation.'</span></div>'; }
					if ($occupation) { echo '<div class="section-box"><b>'._d('Occupation',439).'</b><span class="valuecolumn">'.$occupation.'</span></div>'; }
					?>
				</div> <!-- girlinfo-section -->

				<?php
                if($language1 || $language2 || $language3) {
					echo '<div class="girlinfo-section">';
	                	echo '<h4>'._d('Languages spoken',440).':</h4><div class="clear"></div>';
						if ($language1) { echo "<div class='section-box'><b>".ucfirst($language1).":</b><span class=\"valuecolumn\">".$languagelevel_a[$language1level]."</span></div>"; }
						if ($language2) { echo "<div class='section-box'><b>".ucfirst($language2).":</b><span class=\"valuecolumn\">".$languagelevel_a[$language2level]."</span></div>"; }
						if ($language3) { echo "<div class='section-box'><b>".ucfirst($language3).":</b><span class=\"valuecolumn\">".$languagelevel_a[$language3level]."</span></div>"; }
					echo '</div> <!-- girlinfo-section -->';
				} // if at least one language
				?>

				<div class="girlinfo-section">
	                <h4><?php _de('Contact info',731); ?>:</h4>
	                <div class="clear"></div>
	                <div class="contact">
						<?php
						$location = array();
						$city = wp_get_post_terms(get_the_ID(), $taxonomy_location_url);
						if($city) {
							$location[] = '<b>'._d('City',72).':</b><span class="valuecolumn"><a href="'.get_term_link($city[0]).'" title="'.$city[0]->name.'" itemprop="addressLocality">'.$city[0]->name.'</a></span>';

							$state = get_term($city[0]->parent, $taxonomy_location_url);
							if($state) {
								$state_label = showfield('state') ? _d('State',76) : _d('Country',71);
								$itemprop = showfield('state') ? "addressRegion" : "country";
								$location[] = '<b>'.$state_label.':</b><span class="valuecolumn"><a href="'.get_term_link($state).'" title="'.$state->name.'" itemprop="'.$itemprop.'">'.$state->name.'</a></span>';

								$country = get_term($state->parent, $taxonomy_location_url);
								if(!is_wp_error($country)) {
									$location[] = '<b>'._d('Country',71).':</b><span class="valuecolumn"><a href="'.get_term_link($country).'" title="'.$country->name.'" itemprop="nationality">'.$country->name.'</a></span>';
								}
							}
						}
						echo '<div itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">';
						echo implode("", $location);
						echo '</div>';

						if(get_option("viphide2") && get_option("paymentgateway") && !is_user_logged_in()) {
							echo '<div class="clear5"></div>'.
								'<div class="lockedsection rad5">'.
								_d('You need to',617).' <a href="'.get_permalink(get_option('main_reg_page_id')).'">'._d('register',618).'</a> '._d('or',619).' <a href="'.wp_login_url(get_permalink()).'">'._d('login',620).'</a> '._d('to be able to see the contact information or send a message to this %s',874,$taxonomy_profile_name).'.'.
								'</div>';
						} else {
							$unlocked_escorts = get_user_meta($userid, 'unlocked_escorts', true);
							if(!$unlocked_escorts) $unlocked_escorts = array();
							if(get_option("viphide2") && get_option("paymentgateway") && !get_user_meta($userid, "vip", true) && !in_array(get_the_ID(), $unlocked_escorts) && !current_user_can('level_10') && $profile_author_id != $userid) {
								echo '<div class="clear5"></div><div class="lockedsection rad5">';
								if(get_option("vipunlock") == "yes") {
									echo _d('The contact information for this %s is hidden. To unlock it you need to pay a one time fee of',875)." ";
									echo '<strong>'.format_price('4')."</strong>.";
									echo '<div class="clear10"></div>';
									echo '<div class="center">'.generate_payment_buttons('4',$userid."-".get_the_ID())."</div> <!--center-->";
								} else {
									echo _d('You need to be a VIP member to see the contact information of an %s',881,$taxonomy_profile_name).".<br />";
									echo _d('VIP status costs',879).' <strong>'.format_price('5')."</strong>.<br />";
									if(get_option("vipduration")) {
										echo _d('Your VIP status will be active for',884).' <strong>'.$payment_options_a[get_option("vipduration")][0].'</strong> ';
										if(get_option("vipsubscription") == "yes") {
											echo _d('and you\'ll be billed again after that period expires',885).".";
										}
									}
									echo '<div class="clear10"></div>';
									echo '<div class="center">'.generate_payment_buttons('5',$userid)."</div> <!--center-->";
								}
								echo '</div>';
							} else {
								if ($website) {
									$wraped_website_url = str_replace(array("http://www.", "http://"), "", $website);
									$wraped_website_url = wordwrap($wraped_website_url, 30, " ", true);
									echo '<b>'._d('Website',368).':</b><span class="valuecolumn"><a href="'.$website.'" target="_blank" rel="nofollow" itemprop="url">'.$wraped_website_url.'</a></span>';
								}
						?>
	            	            <?php if($phone) { ?><b><?php _de('Phone',49); ?>:</b><span class="valuecolumn"><a href="tel:<?=$phone?>" itemprop="telephone"><?=$phone?></a></span><?php } ?>
	                            <div class="clear10"></div><a name="contactform"></a>
								<div class="sendemail rad25 bluebutton l"<?php if ($err && $_POST['action'] == "contactform") { echo ' style="display: none;"'; } ?>><span class="icon-mail"></span><?php _de('Contact this %s',784,$taxonomy_profile_name); ?></div>
								<div class="clear"></div>
						<?php
								if ($err && $_POST['action'] == "contactform") { echo '<div class="err rad3">'.$err.'</div>'; }
								if ($ok && $_POST['action'] == "contactform") { echo '<div class="ok rad3">'.$ok.'</div>'; }
								include (get_template_directory() . '/send-email-form.php');
							} // if VIP or admin
						} // if contact section hidden and user not logged in
						?>
						</div> <!-- CONTACT -->
				</div> <!-- girlinfo-section -->
        	</div> <!-- girlinfo -->

            <div class="girlinfo r">
            	<?php if($services || $extraservices) { ?>
	            	<div class="girlinfo-section">
	            		<?php if($services) { ?>
			            	<h4><?php _de('Services',732); ?>:</h4>
			                <div class="services">
								<?php
								foreach($services_a as $key=>$service) {
									if (in_array($key, $services)) {
										echo '<div><span class="icon-ok"></span>'.$service.'</div>';
									} else {
										if(get_option("hideunchedkedservices") != "2") {
											echo '<div><span class="icon-cancel"></span>'.$service.'</div>';
										}
									}
								} // foreach
								?>
			                </div> <!-- SERVICES -->
		                <?php } // if $services ?>
						
		            	<?php if($services && $extraservices) { ?>
							<div class="clear20"></div>
		                <?php } // if $services ?>

						<?php if ($extraservices) { ?>
							<h4><?=_d('Extra Services',449)?>:</h4>
							<div class="services">
								<div class="yes"><?=$extraservices?></div>
							</div>
		                <?php } // if $services ?>
	                </div> <!-- girlinfo-section -->
                <?php } // if $services ?>

				<?php
				if (!$currency) {
					$currency = $currency_a['1'][0];
				} else {
					$currency = $currency_a[$currency][0];
				}
				$rates_sum = $rate30min_incall + $rate1h_incall + $rate2h_incall + $rate3h_incall + $rate6h_incall + $rate12h_incall + $rate24h_incall + $rate30min_outcall + $rate1h_outcall + $rate2h_outcall + $rate3h_outcall + $rate6h_outcall + $rate12h_outcall + $rate24h_outcall;
				if($rates_sum > 0) {
					echo '<div class="girlinfo-section">';
	                	echo '<div class="clear20"></div><h4>'._d('Rates',396).':</h4><div class="clear"></div>';

						echo '<table class="rates-table col100">';
						echo 	'<tr>';
						echo		'<th></th>';
						echo		'<th class="hide-incall">'._d('Incall',258).'</th>';
						echo		'<th class="hide-outcall">'._d('Outcall',259).'</th>';
						echo 	'</tr>';
						if ($rate30min_incall || $rate30min_outcall) {
							echo '<tr><td><strong>30 '._d('minutes',1079).'</strong></td><td class="text-center hide-incall">';
							if ($rate30min_incall) {
								echo $rate30min_incall.' '.$currency;
							}
							echo '</td><td class="text-center hide-outcall">';
							if ($rate30min_outcall) {
								echo $rate30min_outcall.' '.$currency;
							}
							echo '</td></tr>';
						}
						if ($rate1h_incall || $rate1h_outcall) {
							echo '<tr><td><strong>1 '._d('hour',733).'</strong></td><td class="text-center hide-incall">';
							if ($rate1h_incall) {
								echo $rate1h_incall.' '.$currency;
							}
							echo '</td><td class="text-center hide-outcall">';
							if ($rate1h_outcall) {
								echo $rate1h_outcall.' '.$currency;
							}
							echo '</td></tr>';
						}
						if ($rate2h_incall || $rate2h_outcall) {
							echo '<tr><td><strong>2 '._d('hour',733).'</strong></td><td class="text-center hide-incall">';
							if ($rate2h_incall) {
								echo $rate2h_incall.' '.$currency;
							}
							echo '</td><td class="text-center hide-outcall">';
							if ($rate2h_outcall) {
								echo $rate2h_outcall.' '.$currency;
							}
							echo '</td></tr>';
						}
						if ($rate3h_incall || $rate3h_outcall) {
							echo '<tr><td><strong>3 '._d('hour',733).'</strong></td><td class="text-center hide-incall">';
							if ($rate3h_incall) {
								echo $rate3h_incall.' '.$currency;
							}
							echo '</td><td class="text-center hide-outcall">';
							if ($rate3h_outcall) {
								echo $rate3h_outcall.' '.$currency;
							}
							echo '</td></tr>';
						}
						if ($rate6h_incall || $rate6h_outcall) {
							echo '<tr><td><strong>6 '._d('hour',733).'</strong></td><td class="text-center hide-incall">';
							if ($rate6h_incall) {
								echo $rate6h_incall.' '.$currency;
							}
							echo '</td><td class="text-center hide-outcall">';
							if ($rate6h_outcall) {
								echo $rate6h_outcall.' '.$currency;
							}
							echo '</td></tr>';
						}
						if ($rate12h_incall || $rate12h_outcall) {
							echo '<tr><td><strong>12 '._d('hour',733).'</strong></td><td class="text-center hide-incall">';
							if ($rate12h_incall) {
								echo $rate12h_incall.' '.$currency;
							}
							echo '</td><td class="text-center hide-outcall">';
							if ($rate12h_outcall) {
								echo $rate12h_outcall.' '.$currency;
							}
							echo '</td></tr>';
						}
						if ($rate24h_incall || $rate24h_outcall) {
							echo '<tr><td><strong>24 '._d('hour',733).'</strong></td><td class="text-center hide-incall">';
							if ($rate24h_incall) {
								echo $rate24h_incall.' '.$currency;
							}
							echo '</td><td class="text-center hide-outcall">';
							if ($rate24h_outcall) {
								echo $rate24h_outcall.' '.$currency;
							}
							echo '</td></tr>';
						}
						echo '</table>';;

	                	echo '<div class="col30"></div><div class="col30"></div><div class="col30"></div>';

	                	if ($rate30min) { echo ':</b><span class="valuecolumn">'.$rate30min.' '.$currency.'</span>'; }
						if ($rate1h) { echo '<b>:</b><span class="valuecolumn">'.$rate1h.' '.$currency.'</span>'; }
						if ($rate2h) { echo '<b>2 '._d('hours',734).':</b><span class="valuecolumn">'.$rate2h.' '.$currency.'</span>'; }
						if ($rate3h) { echo '<b>3 '._d('hours',734).':</b><span class="valuecolumn">'.$rate3h.' '.$currency.'</span>'; }
						if ($rate6h) { echo '<b>6 '._d('hours',734).':</b><span class="valuecolumn">'.$rate6h.' '.$currency.'</span>'; }
						if ($rate12h) { echo '<b>12 '._d('hours',734).':</b><span class="valuecolumn">'.$rate12h.' '.$currency.'</span>'; }
						if ($rate24h) { echo '<b>24 '._d('hours',734).':</b><span class="valuecolumn">'.$rate24h.' '.$currency.'</span>'; }
					echo '</div> <!-- girlinfo-section -->';
				} // if at least one rate
				?>
				<div class="clear"></div>
            </div> <!-- GIRL INFO RIGHT -->
			<div class="clear20"></div>

			<?php
			$args = array(
				'post_type' => 'tour',
				'post_status' => 'publish',
				'posts_per_page' => -1,
				'meta_query' => array(
					array(
						'key' => 'belongstoescortid',
						'value' => $thispostid,
						'compare' => '=',
						'type' => 'NUMERIC'
					),
					array(
						'key' => 'end',
						'value' => mktime(23, 59, 59, date("m"), date("d"), date("Y")),
						'compare' => '>=',
						'type' => 'NUMERIC'
					)
				)
			);
			query_posts( $args );
			if (have_posts()) : ?>
				<div class="clear30"></div>
				<a name="tours"></a>
				<h4 class="l single-profile-tours-title"><?php _de('Tours',1105); ?>:</h4>
				<div class="clear"></div>
		        <?php if (get_the_author_meta('ID', $profile_author_id) == $userid && $userstatus == $taxonomy_agency_url || current_user_can('level_10')) { ?>
		        <div class="deletemsg r"></div>
		        <?php } ?>
				<div class="clear10"></div>
				<div class="addedtours">
					<div class="tour tourhead">
						<div class="addedstart"><?php _de('Start',545); ?></div>
				    	<div class="addedend"><?php _de('End',546); ?></div>
					    <div class="addedplace"><?php _de('Place',547); ?></div>
				    	<div class="addedphone"><?php _de('Phone',49); ?></div>
					</div>
					<?php
					while ( have_posts() ) : the_post();
						unset($city, $state, $country, $location);

						$city = get_term(get_post_meta(get_the_ID(), 'city', true), $taxonomy_location_url);
						if($city) $location[] = $city->name;

						if(showfield('state')) {
							$state = get_term(get_post_meta(get_the_ID(), 'state', true), $taxonomy_location_url);
							if($state) {
								$location[] = $state->name;
							}
						}

						$country = get_term(get_post_meta(get_the_ID(), 'country', true), $taxonomy_location_url);
						if($country) $location[] = $country->name;
						?>
						<div class="tour" id="tour<?php the_ID(); ?>">
							<span class="tour-info-mobile"><?php _de('Start',545); ?>:</span>
							<div class="addedstart"><?php echo date("d M Y", get_post_meta(get_the_ID(),'start', true)); ?></div>
							<span class="tour-info-mobile-clear"></span>

							<span class="tour-info-mobile"><?php _de('End',546); ?>:</span>
					    	<div class="addedend"><?php echo date("d M Y", get_post_meta(get_the_ID(),'end', true)); ?></div>
					    	<span class="tour-info-mobile-clear"></span>

					    	<span class="tour-info-mobile"><?php _de('Place',547); ?>:</span>
						    <div class="addedplace"><?php echo implode(", ", $location); ?></div>
						    <span class="tour-info-mobile-clear"></span>

						    <span class="tour-info-mobile"><?php _de('Phone',49); ?>:</span>
					    	<div class="addedphone"><a href="tel:<?php echo get_post_meta(get_the_ID(),'phone', true); ?>"><?php echo get_post_meta(get_the_ID(),'phone', true); ?></a></div>

					        <?php
					        if (get_the_author_meta('ID', $profile_author_id) == $userid && $userstatus == $taxonomy_agency_url || current_user_can('level_10')) { ?>
					    	<span class="tour-info-mobile-clear"></span>
					        <div class="addedbuttons">
					        	<?php
					        	if(get_post_status() == "private" && get_post_meta(get_the_ID(), 'needs_payment', true) == "1") {
					        		echo '<div class="pb">'.generate_payment_buttons('3', get_the_ID())."</div>";
					        	} else { ?>
					        		<i><?php the_ID(); ?></i><em><?php the_ID(); ?></em>
					        	<?php } ?>
					        </div>
					        <?php } ?>
						</div>
						<?php
					endwhile;
					?>
					<div class="clear30"></div>
				</div> <!-- ADDED TOURS -->
			<?php endif;
			wp_reset_query();
			?>

			<?php if(!get_option("hide1")) { ?>
				<div class="clear20"></div>
				<h4 class="l" id="addreviewsection"><?php _de('Reviews',735); ?>:</h4>

				<?php
				if ( get_option("escortid".$profile_author_id) == $taxonomy_agency_url && !get_option("hide3")) {
					echo '<a href="'.get_permalink(get_option("agencypostid".$profile_author_id)).'" class="rad25 bluebutton r reviewthegency"><span class="icon-plus-circled"></span>'._d('Review the %s',736,$taxonomy_agency_name).'</a>';
				}
				?>
				<div class="addreview-button rad25 bluebutton r"><span class="icon-plus-circled"></span><?php _de('Add review',685); ?></div>
				<div class="clear"></div>
				<?php
				if ($_GET['postreview'] == "ok") {
					echo '<div class="clear"></div>';
					echo '<div class="ok rad3">';
						if (get_option("manactivesc") == "1") {
							echo _d('Your review will be read by our staff and published soon.',737).'<br />';
						}
						echo _d('Thank you for posting.',682);
					echo '</div>';
				}
				?>
				<div class="addreviewform registerform<?php if($err && $_POST['action'] == 'addreview' && $_GET['postreview'] != "ok") { } else { echo ' hide'; } ?>">
					<?php
					if (!is_user_logged_in()) {
						echo '<div class="err rad3">'._d('You need to',617).' <a href="'.get_permalink(get_option('main_reg_page_id')).'">'._d('register',618).'</a> '._d('or',619).' <a href="'.wp_login_url(get_permalink()).'">'._d('login',620).'</a> '._d('to be able to post a review',706).'</div>';
					} else {
						if ($userstatus == "member" || current_user_can('level_10')) {
							if(did_user_post_review($userid, get_the_ID()) == true) {
								echo '<div class="err rad3">'._d('You can\'t post more than one review for the same %s',738,$taxonomy_profile_name).'</div>';
							} else {
								$unlocked_escorts = get_user_meta($userid, 'unlocked_escorts', true);
								if(!$unlocked_escorts) $unlocked_escorts = array();
								if(get_option("viphide3") && get_option("paymentgateway") && !get_user_meta($userid, "vip", true) && !in_array(get_the_ID(), $unlocked_escorts) && !current_user_can('level_10') && $profile_author_id != $userid) {
									echo '<div class="clear5"></div><div class="lockedsection rad5">';
									if(get_option("vipunlock") == "yes") {
										echo _d('The review section is locked. To unlock it and post a review you need to pay a one time fee of',882)." ";
										echo '<strong>'.format_price('4')."</strong>.";
										echo '<div class="clear10"></div>';
										echo '<div class="center">'.generate_payment_buttons('4',$userid."-".get_the_ID())."</div> <!--center-->";
									} else {
										echo _d('You need to be a VIP member to be able to post a review',883).".<br />";
										echo _d('VIP status costs',879).' <strong>'.format_price('5')."</strong>.<br />";
										if(get_option("vipduration")) {
											echo _d('Your VIP status will be active for',884).' <strong>'.$payment_options_a[get_option("vipduration")][0].'</strong> ';
											if(get_option("vipsubscription") == "yes") {
												echo _d('and you\'ll be billed again after that period expires',885).".";
											}
										}
										echo '<div class="clear10"></div>';
										echo '<div class="center">'.generate_payment_buttons('5',$userid)."</div> <!--center-->";
									}
									echo '</div>';
								} else {
								?>
								<?php if ( $ok && $_POST['action'] == 'addreview') { echo "<div class=\"ok rad3\">$ok</div>"; } ?>
								<?php if ( $err && $_POST['action'] == 'addreview') { echo "<div class=\"err rad3\">$err</div>"; } ?>
								<form action="<?php echo get_permalink(get_the_ID()); ?>#addreview" method="post" class="form-styling">
							    	<?php closebtn(); ?>
							    	<div class="clear10"></div>
								    <input type="hidden" name="action" value="addreview" />
									<div class="form-label">
								    	<label for="rateescort"><?php _de('Rate the %s',761,$taxonomy_profile_name); ?>: <i>*</i></label>
								    </div>
									<div class="form-input">
									    <select name="rateescort" id="rateescort" class="rateescort">
											<option value=""><?php _de('Select',393); ?></option>
								   	    	<option value="5"<?php if($rateescort == "5") { echo ' selected="selected"'; } ?>>5 - <?php _de('perfect',697); ?></option>
								            <option value="4"<?php if($rateescort == "4") { echo ' selected="selected"'; } ?>>4 - <?php _de('good',698); ?></option>
								           	<option value="3"<?php if($rateescort == "3") { echo ' selected="selected"'; } ?>>3 - <?php _de('average',699); ?></option>
								       	    <option value="2"<?php if($rateescort == "2") { echo ' selected="selected"'; } ?>>2 - <?php _de('nothing special',700); ?></option>
								   	        <option value="1"<?php if($rateescort == "1") { echo ' selected="selected"'; } ?>>1 - <?php _de('bad',701); ?></option>
								   	        <option value="6"<?php if($rateescort == "6") { echo ' selected="selected"'; } ?>>0 - <?php _de('waste of time and money',702); ?></option>
										</select>
								    </div> <!-- rate --> <div class="formseparator"></div>

								    <div class="form-label">
										<label for="reviewtext"><?php _de('Comment',703); ?>: <i>*</i></label>
									</div>
									<div class="form-input">
										<textarea name="reviewtext" class="textarea longtextarea" rows="7" id="reviewtext"><?php echo $reviewtext; ?></textarea>
										<div clas="clear"></div>
										<small class="l"><?php _de('html code will be removed',83); ?></small>
										<div class="charcount hides r">
											<div id="barbox"><div id="bar"></div></div>
											<div id="count"></div>
								        </div>
									</div> <!-- review text --> <div class="formseparator"></div>

									<div class="center">
										<div class="clear10"></div>
										<input type="submit" name="submit" value="<?php _de('Add Review',685); ?>" class="bluebutton rad3" />
									</div> <!--center-->
								</form>
								<?php
								} // if review section is locked and user is not VIP
							}
						} else {
							echo '<div class="err rad3">'._d('Your user type is not allowed to post a review here',705).'</div>';
						}
					}
					?>
				</div> <!-- ADD REVIEW FORM-->

				<?php
				$args = array(
					'post_type' => 'review',
					'posts_per_page' => '-1',
					'meta_query' => array(
						array(
							'key' => 'escortid',
							'value' => $thispostid,
							'compare' => '='
						)
					)
				);
				query_posts($args);
				if ( have_posts() ) : ?>
				<div class="clear20"></div>
				<?php
				while ( have_posts() ) : the_post();
					if (get_post_meta(get_the_ID(), 'reviewfor', true) == 'agency') {
						$escort_or_agency = get_post(get_post_meta(get_the_ID(), 'agencyid', true));
						$rating_number = get_post_meta(get_the_ID(), 'rateagency', true);
					} elseif (get_post_meta(get_the_ID(), 'reviewfor', true) == 'profile') {
						$escort_or_agency = get_post(get_post_meta(get_the_ID(), 'escortid', true));
						$rating_number = get_post_meta(get_the_ID(), 'rateescort', true);
					}
					?>
					<div class="review-wrapper rad5">
						<div class="starrating l"><div class="starrating_stars star<?php echo $rating_number; ?>"></div></div>&nbsp;&nbsp;<i><?php echo strtolower(_d('Added by',769)); ?></i>&nbsp;&nbsp;<b><?php echo substr(get_the_author_meta('display_name'), 0, 2); ?>...</b> <i><?php _de('for',963); ?></i> <b><?php echo $escort_or_agency->post_title; ?></b> <i><?php _de('on',1153); ?></i> <b><?php echo the_time("d F Y"); ?></b>
						<?php the_content(); ?>
						<?php edit_post_link(_d('Edit review',1124)); ?>
					</div>
					<div class="clear30"></div>
					<?php endwhile; ?>

					<?php
				else:
					_de('No reviews yet',311);
				endif;
				wp_reset_query();
			} // if !get_option("hide1")

			if (current_user_can('level_10')) {
				echo '<div class="clear10"></div>';
				edit_post_link(_d('Edit in WordPress',686));
			}
			?>
        </div> <!-- GIRL SINGLE -->
	</div> <!-- BODY BOX -->

    <div class="clear"></div>
</div> <!-- BODY -->
</div> <!-- contentwrapper -->

<?php get_sidebar("left"); ?>
<?php get_sidebar("right"); ?>
<div class="clear"></div>
<?php get_footer(); ?>