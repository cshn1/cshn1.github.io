<?php
if(!defined('error_reporting')) { define('error_reporting', '0'); }
ini_set( 'display_errors', error_reporting );
if(error_reporting == '1') { error_reporting( E_ALL ); }
if(isdolcetheme !== 1) { die(); }
?>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$('.agencyeditbuttons .bluebutton').on('click', function(){
			var id = $(this).attr("id");
			$('.agency_options_dropdowns').slideUp();
			$('.agency_options_'+id).slideDown();
			$('.girlsingle, .agencyeditbuttons').slideUp();
		});
		$('.agency_options_dropdowns .closebtn').on('click', function(){
			$(this).parent().slideUp();
			$('.girlsingle, .agencyeditbuttons').slideDown();
		});

	    $('#file_upload').uploadifive({
			'auto'           : true,
			'buttonClass'    : 'bluebutton rad5',
			'buttonText'     : '<?php _de('Upload images',1068) ?>',
			'fileSizeLimit'  : '5MB',
	        'fileType'       : 'image/*',
	        'formData'       : { 'folder' : '<?php echo get_post_meta(get_the_ID(), "secret", true); ?>' },
			'multi'          : true,
			'queueID'        : 'upload-queue',
			'queueSizeLimit' : 20,
			'removeCompleted': true,
			'simUploadLimit' : 10,
			'uploadLimit'    : 20,
			'uploadScript'   : '<?php bloginfo('template_url'); ?>/register-independent-upload-photos-process.php',
			'onQueueComplete': function(data) {
				$('#status-message').html(data.successful + ' <?php _de('images have been uploaded',91); ?>.<br /><'+'a href="<?php echo get_permalink(get_the_ID()); ?>"><?php _de('Refresh the page to see them',485); ?><'+'/a><br /><small><?php _de('Refreshing the page automatically in 2 seconds',1095); ?>.</small>');
				setTimeout(location.reload(), 2000);
			}
		});

		//delete an image from the account
		$('.girlsingle .thumbs .button-delete').on('click', function(){
			var imgid = $(this).parents('.profile-img-thumb').attr('id');
			$('#'+imgid+' img').fadeTo('slow', 0.3).css('z-index', '0');
			$('#'+imgid+' .edit-buttons').html('<div class="preloader r"><'+'/div>');
			loader('#'+imgid+' .edit-buttons .preloader');
			$.ajax({
				type: "GET",
				url: "<?php bloginfo('template_url'); ?>/ajax/delete-uploaded-image.php",
				data: "id=" + imgid,
				success: function(data){
					$('#'+imgid+' .edit-buttons').html('<div class="image_msg_girl_single">'+data+'<'+'/div>');
					setTimeout(function () {
						$('#'+imgid+' .edit-buttons').slideUp();
					    $('#'+imgid).animate({
					    	width: 0},
					    	500, function() {
					    	$(this).hide();
					    });
					}, 2000);
				} // success
			}); // ajax
		}); // click

		<?php if($_POST['action'] == 'addescort' && $err) { echo "$('.girlsingle').slideUp();"."\n\t\t"."$('.agency_options_editprofile').slideDown();"; } ?>
	});
</script>
<div class="agencyeditbuttons">
	<div class="bluebutton rad3 l" id="uploadimages"><?php _de('Add Images',340); ?></div><div class="l">&nbsp;&nbsp;&nbsp;</div>
    <div class="bluebutton rad3 l" id="editclassifiedad"><?php _de('Edit This Ad',341); ?></div><div class="l">&nbsp;&nbsp;&nbsp;</div>
    <div class="bluebutton redbutton rad3 l" id="delete"><?php _de('Delete',89); ?></div>
	<div class="clear10"></div>
</div> <!-- AGENCY EDIT BUTTONS -->

<div class="agency_options_uploadimages agency_options_dropdowns">
	<?php closebtn(); ?>
	<div class="clear10"></div>
	<div class="upload_photos_form">
    	<div class="upload_photos_button r">
			<input id="file_upload" name="file_upload" type="file" />
    	</div>
		<div id="status-message"><?php _de('Click the upload button and select all the images you want to upload.<br />You can upload a maximum of 20 images for this classified ad.<br />Refresh the page to see newly uploaded images.',342); ?></div>
        <div class="clear"></div>
		<div id="upload-queue"></div>
		<div class="clear"></div>
	</div>
</div> <!-- UPLOAD PHOTOS -->

<div class="agency_options_editclassifiedad agency_options_dropdowns">
	<?php closebtn(); ?>
	<?php
	$single_page = "yes";
    include (get_template_directory() . '/manage-classified-ads-form.php');
	?>
</div> <!-- EDIT PROFILE -->

<div class="agency_options_delete agency_options_dropdowns">
	<?php _de('Are you sure you want to delete this classified ad?',343); ?>
	<?php closebtn(); ?>
	<div class="clear10"></div>
	<form action="<?php echo get_permalink(get_the_ID()); ?>" method="post" class="center">
		<input type="submit" name="submit" value="<?php _de('Delete this ad',344); ?>" class="redbutton rad3" />
		<input type="hidden" name="classifiedadidtodelete" value="<?php the_ID(); ?>" />
		<input type="hidden" name="action" value="deleteclassifiedad" />
	</form>
</div> <!-- DELETE -->
<div class="clear10"></div>